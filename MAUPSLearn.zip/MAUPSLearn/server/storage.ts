import { 
  users, type User, type InsertUser, 
  courses, type Course, type InsertCourse,
  videos, type Video, type InsertVideo,
  progress, type Progress, type InsertProgress,
  quizzes, type Quiz, type InsertQuiz,
  quizResults, type QuizResult, type InsertQuizResult,
  challenges, type Challenge, type InsertChallenge,
  challengeParticipants, type ChallengeParticipant, type InsertChallengeParticipant,
  type Question
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserProfile(userId: number, profileData: { displayName?: string, avatar?: string, preferences?: any }): Promise<User | undefined>;
  updateUserPoints(userId: number, points: number): Promise<User | undefined>;
  updateUserStreak(userId: number, streak: number): Promise<User | undefined>;
  updateUserLevel(userId: number, level: number): Promise<User | undefined>;
  getLeaderboard(limit?: number): Promise<User[]>;

  // Course methods
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Video methods
  getVideos(courseId: number): Promise<Video[]>;
  getVideo(id: number): Promise<Video | undefined>;
  getVideoByYouTubeId(videoId: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  
  // Progress methods
  getProgress(userId: number, courseId: number): Promise<Progress[]>;
  getVideoProgress(userId: number, videoId: number): Promise<Progress | undefined>;
  createOrUpdateProgress(progress: InsertProgress): Promise<Progress>;
  
  // Quiz methods
  getQuiz(id: number): Promise<Quiz | undefined>;
  getQuizByVideoId(videoId: number): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  
  // Quiz Results methods
  getQuizResults(userId: number): Promise<QuizResult[]>;
  createQuizResult(result: InsertQuizResult): Promise<QuizResult>;
  
  // Challenge methods
  getChallenges(): Promise<Challenge[]>;
  getChallenge(id: number): Promise<Challenge | undefined>;
  createChallenge(challenge: InsertChallenge): Promise<Challenge>;
  
  // Challenge Participants methods
  getChallengeParticipants(challengeId: number): Promise<ChallengeParticipant[]>;
  getUserChallenges(userId: number): Promise<{challenge: Challenge, participant: ChallengeParticipant}[]>;
  createChallengeParticipant(participant: InsertChallengeParticipant): Promise<ChallengeParticipant>;
  updateChallengeProgress(id: number, progress: number): Promise<ChallengeParticipant | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserPoints(userId: number, points: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ points })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserStreak(userId: number, streak: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ streak })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateUserLevel(userId: number, level: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ level })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }
  
  async updateUserProfile(userId: number, profileData: { displayName?: string, avatar?: string, preferences?: any }): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({
        displayName: profileData.displayName,
        avatar: profileData.avatar,
        // Store preferences in database if we have a specific column for it
        // For now, we'll just update display name and avatar
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async getLeaderboard(limit: number = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.points))
      .limit(limit);
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(insertCourse).returning();
    return course;
  }

  // Video methods
  async getVideos(courseId: number): Promise<Video[]> {
    return await db
      .select()
      .from(videos)
      .where(eq(videos.courseId, courseId))
      .orderBy(videos.position);
  }

  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async getVideoByYouTubeId(videoId: string): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.videoId, videoId));
    return video;
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  // Progress methods
  async getProgress(userId: number, courseId: number): Promise<Progress[]> {
    return await db
      .select()
      .from(progress)
      .where(
        and(
          eq(progress.userId, userId),
          eq(progress.courseId, courseId)
        )
      );
  }

  async getVideoProgress(userId: number, videoId: number): Promise<Progress | undefined> {
    const [videoProgress] = await db
      .select()
      .from(progress)
      .where(
        and(
          eq(progress.userId, userId),
          eq(progress.videoId, videoId)
        )
      );
    return videoProgress;
  }

  async createOrUpdateProgress(insertProgress: InsertProgress): Promise<Progress> {
    const existingProgress = await this.getVideoProgress(
      insertProgress.userId,
      insertProgress.videoId
    );

    if (existingProgress) {
      const [updatedProgress] = await db
        .update(progress)
        .set({
          ...insertProgress,
          lastWatched: new Date()
        })
        .where(eq(progress.id, existingProgress.id))
        .returning();
      return updatedProgress;
    } else {
      const [newProgress] = await db
        .insert(progress)
        .values({
          ...insertProgress,
          lastWatched: new Date()
        })
        .returning();
      return newProgress;
    }
  }

  // Quiz methods
  async getQuiz(id: number): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.id, id));
    return quiz;
  }

  async getQuizByVideoId(videoId: number): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(quizzes).where(eq(quizzes.videoId, videoId));
    return quiz;
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const [quiz] = await db
      .insert(quizzes)
      .values(insertQuiz)
      .returning();
    return quiz;
  }

  // Quiz Results methods
  async getQuizResults(userId: number): Promise<QuizResult[]> {
    return await db
      .select()
      .from(quizResults)
      .where(eq(quizResults.userId, userId))
      .orderBy(desc(quizResults.completedAt));
  }

  async createQuizResult(insertResult: InsertQuizResult): Promise<QuizResult> {
    const [result] = await db
      .insert(quizResults)
      .values({
        ...insertResult,
        completedAt: new Date()
      })
      .returning();
    return result;
  }

  // Challenge methods
  async getChallenges(): Promise<Challenge[]> {
    return await db.select().from(challenges);
  }

  async getChallenge(id: number): Promise<Challenge | undefined> {
    const [challenge] = await db.select().from(challenges).where(eq(challenges.id, id));
    return challenge;
  }

  async createChallenge(insertChallenge: InsertChallenge): Promise<Challenge> {
    const [challenge] = await db.insert(challenges).values(insertChallenge).returning();
    return challenge;
  }

  // Challenge Participants methods
  async getChallengeParticipants(challengeId: number): Promise<ChallengeParticipant[]> {
    return await db
      .select()
      .from(challengeParticipants)
      .where(eq(challengeParticipants.challengeId, challengeId));
  }

  async getUserChallenges(userId: number): Promise<{challenge: Challenge, participant: ChallengeParticipant}[]> {
    const userParticipants = await db
      .select()
      .from(challengeParticipants)
      .where(eq(challengeParticipants.userId, userId));
    
    const result = [];
    for (const participant of userParticipants) {
      const challenge = await this.getChallenge(participant.challengeId);
      if (challenge) {
        result.push({ challenge, participant });
      }
    }
    
    return result;
  }

  async createChallengeParticipant(insertParticipant: InsertChallengeParticipant): Promise<ChallengeParticipant> {
    const [participant] = await db
      .insert(challengeParticipants)
      .values({
        ...insertParticipant,
        completed: insertParticipant.completed || false,
        progress: insertParticipant.progress || 0
      })
      .returning();
    return participant;
  }

  async updateChallengeProgress(id: number, progressValue: number): Promise<ChallengeParticipant | undefined> {
    const [participant] = await db
      .update(challengeParticipants)
      .set({
        progress: progressValue,
        completed: progressValue >= 100
      })
      .where(eq(challengeParticipants.id, id))
      .returning();
    return participant;
  }

  // Initialize test data
  async initializeTestData() {
    // Add some test users
    const testUser = {
      username: "alex",
      password: "password123", // In a real app, this would be hashed
      displayName: "Alex Rivera",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
    };

    // Check if user exists before adding
    const existingUser = await this.getUserByUsername(testUser.username);
    if (!existingUser) {
      const user1 = await this.createUser(testUser);
      // Update points, streak, and level separately
      await this.updateUserPoints(user1.id, 580);
      await this.updateUserStreak(user1.id, 7);
      await this.updateUserLevel(user1.id, 3);
      
      const user2 = await this.createUser({
        username: "sarah",
        password: "password123",
        displayName: "Sarah Johnson",
        avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=256&h=256&auto=format&fit=crop"
      });
      await this.updateUserPoints(user2.id, 720);
      await this.updateUserStreak(user2.id, 12);
      await this.updateUserLevel(user2.id, 4);

      const user3 = await this.createUser({
        username: "michael",
        password: "password123",
        displayName: "Michael Chen",
        avatar: "https://images.unsplash.com/photo-1531427186611-ecfd6d936c79?q=80&w=256&h=256&auto=format&fit=crop"
      });
      await this.updateUserPoints(user3.id, 410);
      await this.updateUserStreak(user3.id, 5);
      await this.updateUserLevel(user3.id, 2);

      const user4 = await this.createUser({
        username: "emily",
        password: "password123",
        displayName: "Emily Wilson",
        avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=256&h=256&auto=format&fit=crop"
      });
      await this.updateUserPoints(user4.id, 890);
      await this.updateUserStreak(user4.id, 15);
      await this.updateUserLevel(user4.id, 5);

      // Add courses
      const course1 = await this.createCourse({
        title: "Introduction to FinTech",
        description: "Learn the fundamentals of financial technology and its impact on the modern financial landscape.",
        playlistId: "PLnZqSPwfwITNgrEMpzAdnE1Br3x0nZGPb",
        thumbnail: "https://img.youtube.com/vi/H_Rva5pfnpI/hqdefault.jpg",
        difficulty: "Beginner",
        category: "FinTech Basics",
        totalVideos: 5
      });

      await this.createCourse({
        title: "Blockchain for Finance",
        description: "Explore how blockchain technology is transforming financial services and transactions.",
        playlistId: "PLnZqSPwfwITN2LNQp0SHdm2XKvI_AOAns",
        thumbnail: "https://img.youtube.com/vi/LSPa_Gx4_rk/hqdefault.jpg",
        difficulty: "Intermediate",
        category: "Blockchain",
        totalVideos: 8
      });

      await this.createCourse({
        title: "Digital Banking Revolution",
        description: "Understand the transformation of traditional banking through digital technologies.",
        playlistId: "PLnZqSPwfwITNx7LRmwZzWXrT1PcxKDcme",
        thumbnail: "https://img.youtube.com/vi/8dUpL8SCO1w/hqdefault.jpg",
        difficulty: "Beginner",
        category: "Banking",
        totalVideos: 6
      });

      // Add videos for the first course
      const video1 = await this.createVideo({
        courseId: course1.id,
        videoId: "H_Rva5pfnpI",
        title: "Introduction to DeFi",
        description: "Learn the basics of Decentralized Finance and its potential impact on traditional financial systems.",
        thumbnail: "https://img.youtube.com/vi/H_Rva5pfnpI/hqdefault.jpg",
        duration: 630, // 10:30
        position: 1
      });

      await this.createVideo({
        courseId: course1.id,
        videoId: "ojWo0n8fmLk",
        title: "FinTech Innovations",
        description: "Explore the latest innovations in financial technology and their real-world applications.",
        thumbnail: "https://img.youtube.com/vi/ojWo0n8fmLk/hqdefault.jpg",
        duration: 545, // 9:05
        position: 2
      });

      await this.createVideo({
        courseId: course1.id,
        videoId: "ZnYIOP2k0js",
        title: "Digital Payment Systems",
        description: "Understand how digital payment systems are changing the way money moves around the world.",
        thumbnail: "https://img.youtube.com/vi/ZnYIOP2k0js/hqdefault.jpg",
        duration: 720, // 12:00
        position: 3
      });

      // Add a quiz for the first video
      await this.createQuiz({
        videoId: video1.id,
        questions: [
          {
            question: "Which of the following best describes DeFi?",
            options: [
              "A type of cryptocurrency",
              "Financial services built on blockchain",
              "A digital banking platform",
              "Government-regulated financial tools"
            ],
            correctOptionIndex: 1
          },
          {
            question: "What is a key characteristic of DeFi platforms?",
            options: [
              "They are controlled by banks",
              "They require traditional financial intermediaries",
              "They are non-custodial, giving users control of their assets",
              "They only work with fiat currencies"
            ],
            correctOptionIndex: 2
          },
          {
            question: "Which blockchain is most commonly used for building DeFi applications?",
            options: [
              "Bitcoin",
              "Ethereum",
              "Dogecoin",
              "Ripple"
            ],
            correctOptionIndex: 1
          }
        ]
      });

      // Add challenges
      const challenge1 = await this.createChallenge({
        title: "FinTech Group Challenge",
        description: "Collaborate with other learners to complete a series of FinTech courses and quizzes.",
        startDate: new Date("2024-05-01"),
        endDate: new Date("2024-06-01"),
        pointsReward: 200,
        isTeamChallenge: true
      });

      const challenge2 = await this.createChallenge({
        title: "30-Day Learning Streak",
        description: "Log in and learn something new every day for 30 consecutive days.",
        startDate: new Date("2024-05-10"),
        endDate: new Date("2024-06-10"),
        pointsReward: 150,
        isTeamChallenge: false
      });

      // Add participants to challenges
      await this.createChallengeParticipant({
        challengeId: challenge1.id,
        userId: 1,
        teamId: 1,
        progress: 45,
        completed: false
      });

      await this.createChallengeParticipant({
        challengeId: challenge2.id,
        userId: 1,
        progress: 23,
        completed: false
      });
    }
  }
}

export const storage = new DatabaseStorage();

// Initialize test data
(async () => {
  try {
    await (storage as DatabaseStorage).initializeTestData();
    console.log("Test data initialized successfully");
  } catch (error) {
    console.error("Error initializing test data:", error);
  }
})();