import { startNgrokTunnel } from './ngrok-tunnel';
import { log } from './vite';

// The port number the application is running on
const PORT = 5000;

// Get command line arguments
const args = process.argv.slice(2);
let options: {
  customSubdomain?: string;
  targetUrl?: string;
  region?: string;
} = {};

// Parse command line arguments
args.forEach((arg) => {
  if (arg.startsWith('--subdomain=')) {
    options.customSubdomain = arg.replace('--subdomain=', '');
  }
  if (arg.startsWith('--url=')) {
    options.targetUrl = arg.replace('--url=', '');
  }
  if (arg.startsWith('--region=')) {
    options.region = arg.replace('--region=', '');
  }
});

// Start the ngrok tunnel
(async () => {
  try {
    if (options.targetUrl) {
      log(`Creating tunnel to: ${options.targetUrl}`, 'start-tunnel');
    } else {
      log(`Creating tunnel to local port: ${PORT}`, 'start-tunnel');
    }
    
    if (options.customSubdomain) {
      log(`Using custom subdomain: ${options.customSubdomain}`, 'start-tunnel');
    }
    
    await startNgrokTunnel(PORT, options);
    log('Press Ctrl+C to stop the tunnel', 'start-tunnel');
  } catch (error: any) {
    log(`Failed to start tunnel: ${error.message}`, 'start-tunnel');
    process.exit(1);
  }
})();