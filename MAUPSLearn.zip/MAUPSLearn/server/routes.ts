import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema, insertProgressSchema, insertQuizResultSchema, insertVideoSchema, type Question } from "@shared/schema";
import { generateQuiz } from "./lib/openai";
import { generateFinancialQuiz, generateTranscriptQuiz } from "./lib/gemini";
import { getYouTubeVideoDetails, getYouTubePlaylistDetails, getYouTubeTranscript, extractPlaylistId } from "./lib/youtube";

export async function registerRoutes(app: Express): Promise<Server> {
  // Serve fintech-learning static files
  app.use('/fintech-learning', express.static('fintech-learning'));
  
  // Auth routes
  app.get("/api/auth/user", async (req: Request, res: Response) => {
    const userId = req.headers['x-replit-user-id'];
    const username = req.headers['x-replit-user-name'];
    
    if (!userId || !username) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    let user = await storage.getUserByUsername(username as string);
    
    if (!user) {
      // Create new user if first time
      user = await storage.createUser({
        username: username as string,
        displayName: username as string,
        password: '', // Not needed with Replit Auth
      });
    }

    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // User routes
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(id);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Return user without password
    const { password: _, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });
  
  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const user = await storage.getUser(id);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    try {
      // Only allow updating certain fields
      const { displayName, avatar, preferences } = req.body;
      const updatedUser = await storage.updateUserProfile(id, { 
        displayName: displayName || user.displayName,
        avatar: avatar || user.avatar,
        preferences
      });
      
      // Return user without password
      if (updatedUser) {
        const { password: _, ...userWithoutPassword } = updatedUser;
        res.json(userWithoutPassword);
      } else {
        res.status(500).json({ message: "Failed to update user profile" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to update user profile" });
    }
  });
  
  app.get("/api/leaderboard", async (_req: Request, res: Response) => {
    const users = await storage.getLeaderboard();
    
    // Remove passwords from users
    const leaderboard = users.map(user => {
      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
    });
    
    res.json(leaderboard);
  });
  
  // Course routes
  app.get("/api/courses", async (_req: Request, res: Response) => {
    const courses = await storage.getCourses();
    res.json(courses);
  });
  
  app.get("/api/courses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    const course = await storage.getCourse(id);
    
    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }
    
    res.json(course);
  });
  
  app.get("/api/courses/:id/videos", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }
    
    const videos = await storage.getVideos(id);
    res.json(videos);
  });
  
  // Video routes
  app.get("/api/videos/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid video ID" });
    }
    
    const video = await storage.getVideo(id);
    
    if (!video) {
      return res.status(404).json({ message: "Video not found" });
    }
    
    res.json(video);
  });

  app.post("/api/videos", async (req: Request, res: Response) => {
    try {
      const videoData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo(videoData);
      res.status(201).json(video);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      console.error("Error creating video:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Progress routes
  app.get("/api/users/:userId/courses/:courseId/progress", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    const courseId = parseInt(req.params.courseId);
    
    if (isNaN(userId) || isNaN(courseId)) {
      return res.status(400).json({ message: "Invalid user ID or course ID" });
    }
    
    const progress = await storage.getProgress(userId, courseId);
    res.json(progress);
  });
  
  app.post("/api/progress", async (req: Request, res: Response) => {
    try {
      const progressData = insertProgressSchema.parse(req.body);
      const progress = await storage.createOrUpdateProgress(progressData);
      res.status(201).json(progress);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Quiz routes
  app.get("/api/videos/:videoId/quiz", async (req: Request, res: Response) => {
    const videoId = parseInt(req.params.videoId);
    
    if (isNaN(videoId)) {
      return res.status(400).json({ message: "Invalid video ID" });
    }
    
    let quiz = await storage.getQuizByVideoId(videoId);
    
    if (!quiz) {
      // If quiz doesn't exist, generate one
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      try {
        // Get transcript from YouTube
        const transcript = await getYouTubeTranscript(video.videoId);
        
        if (!transcript) {
          return res.status(404).json({ message: "Failed to get video transcript" });
        }
        
        // Generate quiz using OpenAI
        const questions = await generateQuiz(video.title, transcript);
        
        if (!questions || questions.length === 0) {
          return res.status(500).json({ message: "Failed to generate quiz" });
        }
        
        // Save quiz to storage
        quiz = await storage.createQuiz({
          videoId,
          questions
        });
      } catch (error) {
        console.error("Error generating quiz:", error);
        return res.status(500).json({ message: "Failed to generate quiz" });
      }
    }
    
    res.json(quiz);
  });
  
  app.post("/api/quizzes/:quizId/submit", async (req: Request, res: Response) => {
    try {
      const quizId = parseInt(req.params.quizId);
      
      if (isNaN(quizId)) {
        return res.status(400).json({ message: "Invalid quiz ID" });
      }
      
      const quiz = await storage.getQuiz(quizId);
      
      if (!quiz) {
        return res.status(404).json({ message: "Quiz not found" });
      }
      
      const { userId, answers } = req.body;
      
      if (!userId || !answers || !Array.isArray(answers)) {
        return res.status(400).json({ message: "Invalid submission" });
      }
      
      // Calculate score
      let score = 0;
      const quizQuestions = quiz.questions as Question[];
      for (let i = 0; i < answers.length; i++) {
        const question = quizQuestions[i];
        if (question && answers[i] === question.correctOptionIndex) {
          score++;
        }
      }
      
      // Save result
      const result = await storage.createQuizResult({
        userId,
        quizId,
        score,
        totalQuestions: quizQuestions.length
      });
      
      // Update user points (10 points per correct answer)
      const user = await storage.getUser(userId);
      if (user) {
        await storage.updateUserPoints(userId, user.points + (score * 10));
      }
      
      res.json({
        result,
        correctAnswers: quizQuestions.map((q: Question) => q.correctOptionIndex)
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Challenge routes
  app.get("/api/challenges", async (_req: Request, res: Response) => {
    const challenges = await storage.getChallenges();
    res.json(challenges);
  });
  
  app.get("/api/users/:userId/challenges", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.userId);
    
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const challenges = await storage.getUserChallenges(userId);
    res.json(challenges);
  });
  
  app.post("/api/challenges/:challengeId/join", async (req: Request, res: Response) => {
    const challengeId = parseInt(req.params.challengeId);
    const { userId, teamId } = req.body;
    
    if (isNaN(challengeId) || !userId) {
      return res.status(400).json({ message: "Invalid challenge ID or user ID" });
    }
    
    const challenge = await storage.getChallenge(challengeId);
    
    if (!challenge) {
      return res.status(404).json({ message: "Challenge not found" });
    }
    
    // Check if user already joined
    const participants = await storage.getChallengeParticipants(challengeId);
    const alreadyJoined = participants.some(p => p.userId === userId);
    
    if (alreadyJoined) {
      return res.status(400).json({ message: "User already joined this challenge" });
    }
    
    const participant = await storage.createChallengeParticipant({
      challengeId,
      userId,
      teamId,
      progress: 0,
      completed: false
    });
    
    res.status(201).json(participant);
  });
  
  app.patch("/api/challenge-participants/:id/progress", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const { progress } = req.body;
    
    if (isNaN(id) || typeof progress !== 'number') {
      return res.status(400).json({ message: "Invalid ID or progress" });
    }
    
    const participant = await storage.updateChallengeProgress(id, progress);
    
    if (!participant) {
      return res.status(404).json({ message: "Participant not found" });
    }
    
    res.json(participant);
  });
  
  // YouTube API proxy
  app.get("/api/youtube/video/:videoId", async (req: Request, res: Response) => {
    const { videoId } = req.params;
    
    try {
      const details = await getYouTubeVideoDetails(videoId);
      res.json(details);
    } catch (error) {
      console.error("Error fetching YouTube video details:", error);
      res.status(500).json({ message: "Failed to fetch video details" });
    }
  });
  
  app.get("/api/youtube/playlist/:playlistId", async (req: Request, res: Response) => {
    const { playlistId } = req.params;
    const maxResults = req.query.maxResults ? parseInt(req.query.maxResults as string) : 10;
    
    try {
      const playlistDetails = await getYouTubePlaylistDetails(playlistId, maxResults);
      res.json(playlistDetails);
    } catch (error) {
      console.error("Error fetching YouTube playlist details:", error);
      res.status(500).json({ message: "Failed to fetch playlist details" });
    }
  });
  
  app.get("/api/youtube/transcript/:videoId", async (req: Request, res: Response) => {
    const { videoId } = req.params;
    
    try {
      const transcript = await getYouTubeTranscript(videoId);
      res.json({ transcript });
    } catch (error) {
      console.error("Error fetching YouTube transcript:", error);
      res.status(500).json({ message: "Failed to fetch video transcript" });
    }
  });
  
  app.get("/api/youtube/extract-playlist-id", async (req: Request, res: Response) => {
    const url = req.query.url as string;
    
    if (!url) {
      return res.status(400).json({ message: "URL parameter is required" });
    }
    
    try {
      const playlistId = extractPlaylistId(url);
      
      if (!playlistId) {
        return res.status(400).json({ message: "Could not extract playlist ID from provided URL" });
      }
      
      res.json({ playlistId });
    } catch (error) {
      console.error("Error extracting playlist ID:", error);
      res.status(500).json({ message: "Failed to extract playlist ID" });
    }
  });

  // Gemini AI Financial Quiz generation
  app.post("/api/gemini/financial-quiz", async (req: Request, res: Response) => {
    const { topic, content, numQuestions } = req.body;

    if (!topic) {
      return res.status(400).json({ message: "Topic is required" });
    }

    try {
      const questions = await generateFinancialQuiz(
        topic, 
        content, 
        numQuestions ? parseInt(numQuestions as string) : 5
      );

      res.json({ questions });
    } catch (error) {
      console.error("Error generating financial quiz with Gemini:", error);
      res.status(500).json({ message: "Failed to generate financial quiz" });
    }
  });

  // Generate quiz from YouTube video transcript using Gemini
  app.get("/api/videos/:videoId/gemini-quiz", async (req: Request, res: Response) => {
    const videoId = parseInt(req.params.videoId);
    
    if (isNaN(videoId)) {
      return res.status(400).json({ message: "Invalid video ID" });
    }
    
    let quiz = await storage.getQuizByVideoId(videoId);
    
    if (!quiz) {
      // If quiz doesn't exist, generate one
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      try {
        // Get transcript from YouTube
        const transcript = await getYouTubeTranscript(video.videoId);
        
        if (!transcript) {
          return res.status(404).json({ message: "Failed to get video transcript" });
        }
        
        // Generate quiz using Gemini
        const questions = await generateTranscriptQuiz(video.title, transcript);
        
        if (!questions || questions.length === 0) {
          return res.status(500).json({ message: "Failed to generate quiz" });
        }
        
        // Save quiz to storage
        quiz = await storage.createQuiz({
          videoId,
          questions
        });
      } catch (error) {
        console.error("Error generating quiz with Gemini:", error);
        return res.status(500).json({ message: "Failed to generate quiz" });
      }
    }
    
    res.json(quiz);
  });
  
  // Generate AI notes from video transcript
  app.get("/api/videos/:videoId/generate-notes", async (req: Request, res: Response) => {
    const { videoId } = req.params;

    if (!videoId || videoId === 'null' || videoId === 'undefined') {
      return res.status(400).json({ message: "A valid video ID is required" });
    }

    try {
      let video;
      let videoTitle;
      let ytVideoId = videoId;
      
      // Check if videoId is a number (database ID) or a string (YouTube video ID)
      if (/^\d+$/.test(videoId)) {
        // It's a database ID
        const videoIdNum = parseInt(videoId);
        if (!isNaN(videoIdNum)) {
          video = await storage.getVideo(videoIdNum);
          if (video) {
            ytVideoId = video.videoId;
            videoTitle = video.title;
          }
        }
      } 
      
      // If we don't have title yet, try to get details directly from YouTube
      if (!videoTitle) {
        try {
          const youtubeVideoDetails = await getYouTubeVideoDetails(ytVideoId);
          if (youtubeVideoDetails) {
            videoTitle = youtubeVideoDetails.title;
          }
        } catch (e) {
          console.log("Could not fetch video details from YouTube:", e);
          // Continue anyway, we'll use a generic title
        }
      }
      
      // If we couldn't get a title, use a generic one
      if (!videoTitle) {
        videoTitle = 'Financial Education Video';
      }
      
      // Get video transcript using YouTube video ID
      const transcript = await getYouTubeTranscript(ytVideoId);
      
      // Use Gemini to generate notes
      const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = await import('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY || '');
      const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
      
      // Safety settings to ensure appropriate content
      const safetySettings = [
        {
          category: HarmCategory.HARM_CATEGORY_HARASSMENT,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
        {
          category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
        {
          category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
        {
          category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
          threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
      ];
      
      const prompt = `You are an expert study note creator. Based on the following transcript from a YouTube video titled "${videoTitle}", 
      create comprehensive, organized study notes that summarize the key concepts, definitions, and takeaways.
      
      Format the notes with clear headings, bullet points, and hierarchy to make them easy to study from.
      Include a "Key Concepts" section at the beginning and a "Summary" section at the end.
      
      Use proper Markdown formatting for the notes with # for main headers, ## for subheaders, 
      - for bullet points, and **bold** for important terms.
      
      Transcript:
      ${transcript}`;
      
      const result = await model.generateContent({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        safetySettings,
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2048,
        },
      });
      const notes = result.response.text();
      
      res.json({ notes });
    } catch (err) {
      const error = err as Error;
      console.error("Error generating notes with Gemini:", error);
      res.status(500).json({ message: "Failed to generate notes", error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
