import { type Question } from "@shared/schema";

/**
 * Generate a quiz based on video title and transcript
 * @param videoTitle The title of the video
 * @param transcript The transcript of the video
 * @returns An array of quiz questions
 */
export async function generateQuiz(videoTitle: string, transcript: string): Promise<Question[]> {
  // Instead of using OpenAI, return preset questions based on the video title
  // In a real application with the API key, we would generate questions based on the transcript
  console.log(`Generating preset quiz for video: ${videoTitle}`);
  
  // Preset quizzes for different videos - we can identify the topic from the title
  if (videoTitle.toLowerCase().includes("defi") || videoTitle.toLowerCase().includes("decentralized finance")) {
    return [
      {
        question: "What is the primary technology that powers DeFi applications?",
        options: [
          "Artificial Intelligence",
          "Blockchain",
          "Cloud Computing",
          "Quantum Computing"
        ],
        correctOptionIndex: 1
      },
      {
        question: "Which of the following is a key characteristic of DeFi platforms?",
        options: [
          "They require a bank account to use",
          "They are controlled by central banks",
          "They are non-custodial, giving users control of their assets",
          "They only work with traditional fiat currencies"
        ],
        correctOptionIndex: 2
      },
      {
        question: "What are smart contracts in the context of DeFi?",
        options: [
          "Legal agreements written by lawyers",
          "Self-executing contracts with code-defined terms",
          "Traditional bank loan agreements",
          "Investment contracts managed by financial advisors"
        ],
        correctOptionIndex: 1
      }
    ];
  } else if (videoTitle.toLowerCase().includes("mobile banking") || videoTitle.toLowerCase().includes("digital banking")) {
    return [
      {
        question: "What is a key advantage of mobile banking over traditional banking?",
        options: [
          "Higher interest rates on savings",
          "More personal relationship with bankers",
          "24/7 access to banking services",
          "Lower risk of fraud"
        ],
        correctOptionIndex: 2
      },
      {
        question: "Which security feature is commonly used in mobile banking apps?",
        options: [
          "Paper verification codes",
          "Biometric authentication",
          "In-person signature verification",
          "Physical security tokens"
        ],
        correctOptionIndex: 1
      },
      {
        question: "What technology enables contactless payments through mobile devices?",
        options: [
          "Bluetooth",
          "Wi-Fi Direct",
          "Near Field Communication (NFC)",
          "QR Code scanning"
        ],
        correctOptionIndex: 2
      }
    ];
  } else if (videoTitle.toLowerCase().includes("payment") || videoTitle.toLowerCase().includes("fintech innovations")) {
    return [
      {
        question: "Which of the following is NOT typically a feature of modern payment systems?",
        options: [
          "Real-time transaction processing",
          "Cross-border payment capabilities",
          "Manual approval for all transactions",
          "Integration with mobile wallets"
        ],
        correctOptionIndex: 2
      },
      {
        question: "What is the primary benefit of blockchain in payment systems?",
        options: [
          "Increased transaction privacy",
          "Reduced transaction costs and settlement time",
          "Higher transaction limits",
          "Mandatory insurance on all transactions"
        ],
        correctOptionIndex: 1
      },
      {
        question: "Which of these is an example of a peer-to-peer payment system?",
        options: [
          "Credit cards",
          "Bank wire transfers",
          "Venmo",
          "ATM withdrawals"
        ],
        correctOptionIndex: 2
      }
    ];
  } else {
    // Default questions for other FinTech videos
    return [
      {
        question: "Which of the following best represents the core concept of FinTech?",
        options: [
          "Using technology to improve and automate financial services",
          "Creating new forms of physical currency",
          "Traditional banking services offered online",
          "Government regulation of financial markets"
        ],
        correctOptionIndex: 0
      },
      {
        question: "What has been a major driver of FinTech adoption globally?",
        options: [
          "Decreasing internet usage",
          "Smartphone penetration",
          "Reduced interest in digital services",
          "Increasing preference for in-person banking"
        ],
        correctOptionIndex: 1
      },
      {
        question: "Which area has seen significant innovation due to FinTech?",
        options: [
          "Paper check processing",
          "In-person banking services",
          "Digital payments and transfers",
          "Physical currency design"
        ],
        correctOptionIndex: 2
      }
    ];
  }
}
