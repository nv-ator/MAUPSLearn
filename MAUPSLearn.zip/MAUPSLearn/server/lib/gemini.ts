/**
 * This module provides utilities for generating financial quizzes using Google's Gemini AI
 */

import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";
import { Question } from "../../shared/schema";

// Initialize the Google Generative AI with the API key
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY as string);

// Safety settings to ensure appropriate content
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
  },
];

/**
 * Generate a financial quiz based on a topic and optional content
 * 
 * @param topic The financial topic to generate a quiz for
 * @param content Optional additional content to use when generating the quiz
 * @param numQuestions Number of questions to generate (default: 5)
 * @returns An array of quiz questions
 */
export async function generateFinancialQuiz(
  topic: string, 
  content?: string, 
  numQuestions: number = 5
): Promise<Question[]> {
  try {
    // Access the generative model (Gemini)
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" }); // Using gemini-1.5-pro which is the latest model as of April 2025

    // Construct the prompt
    let prompt = `Generate a multiple choice financial quiz about "${topic}" with ${numQuestions} questions. 
    
Each question should have 4 options with only one correct answer. 
Make sure the questions test understanding of financial concepts and are educational.
The questions should be challenging but fair for someone learning about finance.

Return the result as a JSON array with the following structure:
[
  {
    "question": "Question text here?",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctOptionIndex": 0 // Index of the correct option (0-3)
  }
]`;

    // Add content to the prompt if provided
    if (content) {
      prompt += `\n\nBase the questions on this content:\n${content}`;
    }

    // Generate content
    const result = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      safetySettings,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 2048,
      },
    });

    const response = result.response;
    const text = response.text();

    // Find JSON array in the response text
    let jsonText = text;
    
    // Try to find the start of the JSON array
    const startIdx = text.indexOf('[');
    const endIdx = text.lastIndexOf(']');
    
    if (startIdx !== -1 && endIdx !== -1 && startIdx < endIdx) {
      jsonText = text.substring(startIdx, endIdx + 1);
    }

    // Parse the JSON
    try {
      const quizQuestions = JSON.parse(jsonText) as Question[];

      // Validate the questions
      if (!Array.isArray(quizQuestions) || quizQuestions.length === 0) {
        throw new Error("Invalid response format from Gemini");
      }

      return quizQuestions;
    } catch (parseError) {
      console.error("Error parsing JSON from Gemini response:", parseError);
      throw new Error("Failed to parse quiz questions from Gemini response");
    }
  } catch (error) {
    console.error("Error generating quiz with Gemini:", error);
    
    // Return a fallback set of generic financial questions
    return [
      {
        question: "What is compound interest?",
        options: [
          "Interest calculated on the initial principal only",
          "Interest calculated on the initial principal and accumulated interest",
          "Interest that compounds once per year only",
          "A fixed interest rate that never changes"
        ],
        correctOptionIndex: 1
      },
      {
        question: "What is diversification in investing?",
        options: [
          "Investing all your money in one promising stock",
          "Spreading investments across various assets to reduce risk",
          "Changing your investment strategy frequently",
          "Investing only in government bonds"
        ],
        correctOptionIndex: 1
      },
      {
        question: "What is a bear market?",
        options: [
          "A market where stock prices are rising",
          "A market focused on commodities",
          "A market where stock prices are falling",
          "A market exclusive to high-risk investors"
        ],
        correctOptionIndex: 2
      },
      {
        question: "What is a P/E ratio used for?",
        options: [
          "Measuring a company's current debt",
          "Comparing a company's stock price to its earnings per share",
          "Calculating dividend payments",
          "Determining a company's market capitalization"
        ],
        correctOptionIndex: 1
      },
      {
        question: "What is a liquidity ratio?",
        options: [
          "A measure of how quickly a company can pay off short-term debts",
          "The ratio of stocks to bonds in a portfolio",
          "A measure of how quickly a stock price changes",
          "The ratio of international to domestic investments"
        ],
        correctOptionIndex: 0
      }
    ];
  }
}

/**
 * Generate a quiz based on a YouTube video transcript
 * 
 * @param videoTitle The title of the video
 * @param transcript The transcript of the video
 * @param numQuestions Number of questions to generate (default: 5)
 * @returns An array of quiz questions
 */
export async function generateTranscriptQuiz(
  videoTitle: string, 
  transcript: string, 
  numQuestions: number = 5
): Promise<Question[]> {
  // If the transcript is too long, trim it to the first 15,000 characters
  const trimmedTranscript = transcript.length > 15000 
    ? transcript.substring(0, 15000) + "..." 
    : transcript;
  
  return generateFinancialQuiz(videoTitle, trimmedTranscript, numQuestions);
}