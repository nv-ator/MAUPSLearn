/**
 * This module provides utilities for interacting with YouTube API
 */
import fetch from 'node-fetch';

// YouTube API configuration
const YOUTUBE_API_KEY = process.env.YOUTUBE_API_KEY || 'AIzaSyB32O5C4wnn6PgQnyFC60OtcbVXdzK1UZU';
const YOUTUBE_API_BASE_URL = 'https://www.googleapis.com/youtube/v3';

/**
 * Get details about a YouTube video
 * @param videoId The YouTube video ID
 * @returns Video details including title, description, etc.
 */
export async function getYouTubeVideoDetails(videoId: string) {
  try {
    // Validate video ID
    if (!videoId) {
      console.error("getYouTubeVideoDetails called with null or empty videoId");
      throw new Error("Invalid video ID: null or empty");
    }
    
    console.log(`Fetching YouTube video details for ID: ${videoId}`);
    
    // Create API URL
    const apiUrl = `${YOUTUBE_API_BASE_URL}/videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${YOUTUBE_API_KEY}`;
    
    // Make API request
    console.log(`Making YouTube API request for video ${videoId}`);
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      console.error(`YouTube API error: ${response.status} ${response.statusText}`);
      throw new Error(`YouTube API returned ${response.status}: ${response.statusText}`);
    }

    // Parse response
    const data = await response.json();
    console.log(`YouTube API response received with ${data.items?.length || 0} items`);

    if (data.items && data.items.length > 0) {
      const videoDetails = data.items[0];
      const snippet = videoDetails.snippet;
      const contentDetails = videoDetails.contentDetails;
      
      // Parse ISO 8601 duration
      const duration = parseDuration(contentDetails.duration);
      
      const result = {
        title: snippet.title,
        description: snippet.description,
        publishedAt: snippet.publishedAt,
        channelTitle: snippet.channelTitle,
        thumbnail: snippet.thumbnails.high?.url || snippet.thumbnails.default?.url,
        duration: duration, // in seconds
        viewCount: videoDetails.statistics?.viewCount || 0,
        likeCount: videoDetails.statistics?.likeCount || 0
      };
      
      console.log(`Successfully retrieved details for video: ${result.title}`);
      return result;
    } else {
      console.error(`No video found with ID: ${videoId}`);
      throw new Error(`No video found with ID: ${videoId}`);
    }
  } catch (error) {
    console.error('Error fetching YouTube video details:', error);
    // Fallback to default data if API fails
    return {
      title: `Video ${videoId}`,
      description: "Video description not available.",
      duration: 300, // default 5 minutes
      thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
    };
  }
}

/**
 * Get details about a YouTube playlist
 * @param playlistId The YouTube playlist ID
 * @returns Playlist details and videos
 */
export async function getYouTubePlaylistDetails(playlistId: string, maxResults = 10) {
  try {
    // Get playlist info
    const playlistResponse = await fetch(`${YOUTUBE_API_BASE_URL}/playlists?part=snippet,contentDetails&id=${playlistId}&key=${YOUTUBE_API_KEY}`);
    
    if (!playlistResponse.ok) {
      throw new Error(`YouTube API returned ${playlistResponse.status}: ${playlistResponse.statusText}`);
    }

    const playlistData = await playlistResponse.json();

    if (!playlistData.items || playlistData.items.length === 0) {
      throw new Error(`No playlist found with ID: ${playlistId}`);
    }

    const playlistInfo = playlistData.items[0];

    // Get playlist items
    const playlistItemsResponse = await fetch(`${YOUTUBE_API_BASE_URL}/playlistItems?part=snippet,contentDetails&playlistId=${playlistId}&maxResults=${maxResults}&key=${YOUTUBE_API_KEY}`);
    
    if (!playlistItemsResponse.ok) {
      throw new Error(`YouTube API returned ${playlistItemsResponse.status}: ${playlistItemsResponse.statusText}`);
    }

    const itemsData = await playlistItemsResponse.json();

    const videos = [];

    if (itemsData.items && itemsData.items.length > 0) {
      // Process each video in the playlist
      for (const item of itemsData.items) {
        const videoId = item.snippet.resourceId.videoId;
        
        // Get additional video details, including duration
        try {
          const videoDetails = await getYouTubeVideoDetails(videoId);
          
          videos.push({
            id: videoId,
            title: item.snippet.title,
            description: item.snippet.description,
            thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.default?.url,
            position: item.snippet.position,
            duration: videoDetails.duration
          });
        } catch (error) {
          // If we can't get details, still add the video with basic info
          videos.push({
            id: videoId,
            title: item.snippet.title,
            description: item.snippet.description,
            thumbnail: item.snippet.thumbnails.high?.url || item.snippet.thumbnails.default?.url,
            position: item.snippet.position,
            duration: 0
          });
        }
      }
    }

    return {
      id: playlistInfo.id,
      title: playlistInfo.snippet.title,
      description: playlistInfo.snippet.description,
      thumbnail: playlistInfo.snippet.thumbnails.high?.url || playlistInfo.snippet.thumbnails.default?.url,
      itemCount: playlistInfo.contentDetails.itemCount,
      videos: videos
    };
  } catch (error) {
    console.error('Error fetching YouTube playlist details:', error);
    return {
      id: playlistId,
      title: 'Playlist Not Available',
      description: 'This playlist information could not be retrieved.',
      thumbnail: '',
      itemCount: 0,
      videos: []
    };
  }
}

/**
 * Get the transcript of a YouTube video
 * Note: YouTube's API doesn't directly provide transcripts. 
 * This is a placeholder that could be replaced with a third-party solution.
 * 
 * @param videoId The YouTube video ID
 * @returns The transcript text or an error message
 */
export async function getYouTubeTranscript(videoId: string): Promise<string> {
  try {
    // This is a placeholder as YouTube API doesn't provide transcript access
    // In a production environment, you would use a third-party service or library
    
    // Get video details to build a more informative placeholder
    const videoDetails = await getYouTubeVideoDetails(videoId);
    
    return `
Transcript for: "${videoDetails.title}"

Note: This is a simulated transcript as the YouTube API doesn't provide direct access to video transcripts.
In a production environment, you would need to use a third-party service to get actual transcripts.

Video description:
${videoDetails.description.slice(0, 300)}${videoDetails.description.length > 300 ? '...' : ''}
    `;
  } catch (error) {
    console.error('Error fetching transcript:', error);
    return `No transcript available for video ID: ${videoId}`;
  }
}

/**
 * Extract playlist ID from a YouTube playlist URL
 * @param url YouTube playlist URL
 * @returns Playlist ID or null if not found
 */
export function extractPlaylistId(url: string): string | null {
  try {
    const urlObj = new URL(url);
    const params = new URLSearchParams(urlObj.search);
    return params.get('list');
  } catch (error) {
    console.error('Error extracting playlist ID:', error);
    return null;
  }
}

/**
 * Helper function to parse ISO 8601 duration format
 * @param isoDuration ISO 8601 duration string (e.g., PT1H30M15S)
 * @returns Duration in seconds
 */
function parseDuration(isoDuration: string): number {
  const match = isoDuration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  
  if (!match) {
    return 0;
  }
  
  const hours = parseInt(match[1] || '0', 10);
  const minutes = parseInt(match[2] || '0', 10);
  const seconds = parseInt(match[3] || '0', 10);
  
  return hours * 3600 + minutes * 60 + seconds;
}
