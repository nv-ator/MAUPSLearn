import ngrok from 'ngrok';
import { log } from './vite';

// Define valid ngrok regions
type Region = "us" | "eu" | "au" | "ap" | "sa" | "jp" | "in";

/**
 * Interface for ngrok connect options
 */
interface ConnectOptions {
  addr: string | number;
  subdomain?: string;
  region?: Region;
  onStatusChange?: (status: string) => void;
  onLogEvent?: (data: string) => void;
}

/**
 * Start ngrok tunnel to expose the application
 * @param port The port number the application is running on
 * @param options Optional configuration for the ngrok tunnel
 */
export async function startNgrokTunnel(
  port: number, 
  options?: {
    customSubdomain?: string;
    targetUrl?: string;
    region?: string;
  }
): Promise<void> {
  try {
    // Set auth token from environment variables
    if (!process.env.NGROK_AUTHTOKEN) {
      log('⚠️ No NGROK_AUTHTOKEN environment variable found. Some features might be limited.', 'ngrok');
    }
    
    await ngrok.authtoken(process.env.NGROK_AUTHTOKEN || '');
    
    // Determine the address to tunnel to
    const addr = options?.targetUrl || port;
    
    // Create connect options
    const connectOptions: ConnectOptions = {
      addr,
      subdomain: options?.customSubdomain,
      onStatusChange: (status: string) => {
        log(`Ngrok Status: ${status}`, 'ngrok');
      },
      onLogEvent: (data: string) => {
        log(`Ngrok Log: ${data}`, 'ngrok');
      },
    };
    
    // Add region if it's valid
    if (options?.region) {
      const validRegions: Region[] = ['us', 'eu', 'ap', 'au', 'sa', 'jp', 'in'];
      if (validRegions.includes(options.region as Region)) {
        connectOptions.region = options.region as Region;
      }
    }
    
    // Start ngrok tunnel
    const url = await ngrok.connect(connectOptions);

    log(`🚀 Ngrok tunnel is running at: ${url}`, 'ngrok');
    log('To stop the tunnel, press Ctrl+C to terminate the process', 'ngrok');
  } catch (error: any) {
    log(`❌ Error starting ngrok tunnel: ${error.message || 'Unknown error'}`, 'ngrok');
    
    // Check if the error is due to missing auth token
    if (error.message && error.message.includes('authtoken')) {
      log('💡 You need an ngrok account and authtoken to use custom subdomains and other advanced features.', 'ngrok');
      log('💡 Visit https://dashboard.ngrok.com/get-started/your-authtoken to get your authtoken.', 'ngrok');
      log('💡 Then add it to your environment variables as NGROK_AUTHTOKEN.', 'ngrok');
    }
    
    throw error;
  }
}