import ngrok from 'ngrok';
import { log } from './vite';

// Stop the ngrok tunnel
(async () => {
  try {
    await ngrok.disconnect();
    await ngrok.kill();
    log('Successfully stopped ngrok tunnel', 'stop-tunnel');
  } catch (error: any) {
    log(`Error stopping ngrok tunnel: ${error.message}`, 'stop-tunnel');
    process.exit(1);
  }
})();