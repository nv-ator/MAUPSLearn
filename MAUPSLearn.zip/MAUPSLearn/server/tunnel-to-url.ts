import { startNgrokTunnel } from './ngrok-tunnel';
import { log } from './vite';

// Default values
const DEFAULT_TARGET_URL = 'upright-gratefully-alpaca.ngrok-free.app';
const DEFAULT_PORT = 80;

// Get command line arguments
const args = process.argv.slice(2);
let options: {
  targetUrl?: string;
  port?: number;
  customSubdomain?: string;
  region?: string;
} = {};

// Parse command line arguments
args.forEach((arg) => {
  if (arg.startsWith('--url=')) {
    options.targetUrl = arg.replace('--url=', '');
  }
  if (arg.startsWith('--port=')) {
    options.port = parseInt(arg.replace('--port=', ''), 10);
  }
  if (arg.startsWith('--subdomain=')) {
    options.customSubdomain = arg.replace('--subdomain=', '');
  }
  if (arg.startsWith('--region=')) {
    options.region = arg.replace('--region=', '');
  }
});

// Use defaults if not provided
const TARGET_URL = options.targetUrl || DEFAULT_TARGET_URL;
const PORT = options.port || DEFAULT_PORT;

// Start the ngrok tunnel to the specified URL
(async () => {
  try {
    log(`Creating ngrok tunnel to remote URL: ${TARGET_URL}`, 'tunnel-to-url');
    
    // Add subdomain and region if provided
    const tunnelOptions = {
      targetUrl: `http://${TARGET_URL}`,
      customSubdomain: options.customSubdomain,
      region: options.region
    };
    
    await startNgrokTunnel(PORT, tunnelOptions);
    
    log('Press Ctrl+C to stop the tunnel', 'tunnel-to-url');
  } catch (error: any) {
    log(`Failed to start tunnel: ${error.message}`, 'tunnel-to-url');
    process.exit(1);
  }
})();