import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";

import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Courses from "@/pages/courses";
import Quizzes from "@/pages/quizzes";
import Achievements from "@/pages/achievements";
import Community from "@/pages/community";
import Wellness from "@/pages/wellness";
import Settings from "@/pages/settings";
import CoursePlayer from "@/pages/course-player";
import PlaylistViewer from "@/pages/playlist-viewer";
import QuizGenerator from "@/pages/quiz-generator";
import AINotesGenerator from "@/pages/ai-notes-maker";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import ChatbotWrapper from "@/components/chatbot-wrapper";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/courses">
        {() => { window.location.href = '/playlist'; return null; }}
      </Route>
      <Route path="/courses/:courseId" component={CoursePlayer} />
      <Route path="/achievements" component={Achievements} />
      <Route path="/community" component={Community} />
      <Route path="/wellness" component={Wellness} />
      <Route path="/settings" component={Settings} />
      <Route path="/playlist" component={PlaylistViewer} />
      <Route path="/playlist/:playlistId" component={PlaylistViewer} />
      <Route path="/quiz-generator" component={QuizGenerator} />
      <Route path="/ai-notes-maker" component={AINotesGenerator} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex flex-col md:flex-row h-screen">
        <Sidebar />
        <main className="flex-1 md:pl-64">
          <Router />
          <MobileNav />
        </main>
        <ChatbotWrapper />
        <Toaster />
      </div>
    </QueryClientProvider>
  );
}

export default App;