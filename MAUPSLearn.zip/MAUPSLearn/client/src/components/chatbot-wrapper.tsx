import React from 'react';
import Chatbot from '@/components/ui/chatbot';

export const ChatbotWrapper: React.FC = () => {
  return <Chatbot />;
};

export default ChatbotWrapper;