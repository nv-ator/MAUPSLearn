import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Question as QuestionType } from "@/lib/types";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Lightbulb, CheckCircle, XCircle } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface QuizProps {
  questions: QuestionType[];
  onComplete: (score: number, answers: number[]) => void;
  isLoading?: boolean;
}

export function Quiz({ questions, onComplete, isLoading = false }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>(Array(questions.length).fill(-1));
  const [showResults, setShowResults] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  const handleAnswerSelect = (value: string) => {
    const answerIndex = parseInt(value);
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestion] = answerIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setShowExplanation(false);
    } else {
      // Calculate score
      const score = selectedAnswers.reduce((total, answer, index) => {
        return answer === questions[index].correctOptionIndex ? total + 1 : total;
      }, 0);
      
      setShowResults(true);
      onComplete(score, selectedAnswers);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setShowExplanation(false);
    }
  };

  // Calculate progress percentage
  const progressPercentage = ((currentQuestion + 1) / questions.length) * 100;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Lightbulb className="mr-2 h-5 w-5 text-primary-500" />
            Loading Quiz...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 animate-pulse">
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
            <div className="space-y-2">
              <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
              <div className="h-10 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (showResults) {
    const score = selectedAnswers.reduce((total, answer, index) => {
      return answer === questions[index].correctOptionIndex ? total + 1 : total;
    }, 0);
    
    const percentage = Math.round((score / questions.length) * 100);
    
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Quiz Results</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center text-center">
          <div className="w-32 h-32 rounded-full border-8 border-primary-100 dark:border-primary-900 flex items-center justify-center mb-6">
            <span className="text-4xl font-bold text-primary-600 dark:text-primary-400">{percentage}%</span>
          </div>
          
          <p className="text-xl font-medium mb-2">
            You scored {score} out of {questions.length}
          </p>
          
          <p className="text-gray-500 dark:text-gray-400 mb-6">
            {percentage >= 80 ? "Great job! You've mastered this topic."
            : percentage >= 60 ? "Good work! You understand most of the concepts."
            : "Keep learning! Review the material and try again."}
          </p>
          
          <div className="w-full space-y-4 mb-6">
            {questions.map((question, index) => (
              <div key={index} className="text-left border rounded-lg p-4">
                <div className="flex items-start">
                  {selectedAnswers[index] === question.correctOptionIndex ? (
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 mt-0.5 mr-2 flex-shrink-0" />
                  )}
                  <div>
                    <p className="font-medium">{question.question}</p>
                    <p className="text-sm mt-1">
                      <span className="text-gray-500 dark:text-gray-400">Your answer: </span>
                      <span className={cn(
                        selectedAnswers[index] === question.correctOptionIndex ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400",
                        "font-medium"
                      )}>
                        {question.options[selectedAnswers[index]]}
                      </span>
                    </p>
                    {selectedAnswers[index] !== question.correctOptionIndex && (
                      <p className="text-sm mt-1">
                        <span className="text-gray-500 dark:text-gray-400">Correct answer: </span>
                        <span className="text-green-600 dark:text-green-400 font-medium">
                          {question.options[question.correctOptionIndex]}
                        </span>
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={() => window.location.reload()}>
            Try Another Quiz
          </Button>
        </CardFooter>
      </Card>
    );
  }

  const question = questions[currentQuestion];

  return (
    <Card>
      <CardHeader className="border-b bg-primary-50 dark:bg-gray-700">
        <div className="flex justify-between items-center">
          <CardTitle className="text-primary-700 dark:text-primary-300 flex items-center text-base md:text-lg">
            <Lightbulb className="mr-2 h-5 w-5" />
            Quiz Question {currentQuestion + 1} of {questions.length}
          </CardTitle>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 dark:bg-primary-900 text-primary-800 dark:text-primary-300">
            <Lightbulb className="mr-1 h-3 w-3" /> AI-Generated
          </span>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        <Progress value={progressPercentage} className="mb-4" />
        
        <p className="text-gray-900 dark:text-white font-medium mb-4">
          {question.question}
        </p>
        
        <RadioGroup
          value={selectedAnswers[currentQuestion].toString()}
          onValueChange={handleAnswerSelect}
          className="space-y-2"
        >
          {question.options.map((option, index) => (
            <div
              key={index}
              className={cn(
                "flex items-center p-3 border rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer",
                selectedAnswers[currentQuestion] === index && "bg-primary-50 dark:bg-primary-900/20 border-primary-300 dark:border-primary-700"
              )}
            >
              <RadioGroupItem
                id={`option-${index}`}
                value={index.toString()}
                className="mr-3"
              />
              <Label
                htmlFor={`option-${index}`}
                className="cursor-pointer flex-1 text-sm font-medium text-gray-700 dark:text-gray-300"
              >
                {option}
              </Label>
            </div>
          ))}
        </RadioGroup>
        
        {showExplanation && (
          <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 rounded-md">
            <p className="text-sm">
              <span className="font-semibold">Explanation:</span> The correct answer is {question.options[question.correctOptionIndex]}.
            </p>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="outline"
          disabled={currentQuestion === 0}
          onClick={handlePrevious}
        >
          Previous
        </Button>
        
        <div className="flex gap-2">
          {!showExplanation && selectedAnswers[currentQuestion] !== -1 && (
            <Button 
              variant="secondary"
              onClick={() => setShowExplanation(true)}
            >
              Show Explanation
            </Button>
          )}
          
          <Button
            disabled={selectedAnswers[currentQuestion] === -1}
            onClick={handleNext}
          >
            {currentQuestion < questions.length - 1 ? "Next" : "Finish Quiz"}
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
