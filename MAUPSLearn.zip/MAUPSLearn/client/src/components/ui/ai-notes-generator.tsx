import { useState } from 'react';
import { Button } from './button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './card';
import { Skeleton } from './skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './tabs';
import { apiRequest } from '@/lib/queryClient';
import { FileText, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Markdown } from '@/components/ui/markdown';

interface AINotesGeneratorProps {
  videoId: string | null;
  videoTitle?: string;
}

export function AINotesGenerator({ videoId, videoTitle }: AINotesGeneratorProps) {
  const [notes, setNotes] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const generateNotes = async () => {
    if (!videoId) {
      toast({
        title: "No video selected",
        description: "Please select a video to generate notes for.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const result = await apiRequest<{ notes: string }>(
        `/api/videos/${videoId}/generate-notes`
      );
      
      setNotes(result.notes);
      setLoading(false);
      
      toast({
        title: "Notes generated",
        description: "Your AI study notes have been generated successfully."
      });
    } catch (err) {
      console.error('Error generating notes:', err);
      setError('Failed to generate notes. Please try again later.');
      setLoading(false);
      
      toast({
        title: "Error",
        description: "Failed to generate notes. Please try again later.",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="w-full mt-6">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-xl flex items-center">
          <FileText className="h-5 w-5 mr-2" />
          AI Study Notes
        </CardTitle>
        <Button
          variant="secondary"
          size="sm"
          onClick={generateNotes}
          disabled={loading || !videoId}
        >
          {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
          {notes ? "Regenerate Notes" : "Generate Notes"}
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-5/6" />
            <Skeleton className="h-6 w-2/4 mt-4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
          </div>
        ) : error ? (
          <div className="text-red-500 py-4">
            <p>{error}</p>
            <p className="text-sm mt-2">Make sure your Google AI API key is properly configured.</p>
          </div>
        ) : notes ? (
          <div className="max-h-[500px] overflow-y-auto pr-2">
            <Markdown content={notes} />
          </div>
        ) : (
          <div className="text-center py-10 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Select a video and click "Generate Notes" to create AI-powered study notes.</p>
            <p className="text-sm mt-2">Notes will include key concepts, definitions, and summaries.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}