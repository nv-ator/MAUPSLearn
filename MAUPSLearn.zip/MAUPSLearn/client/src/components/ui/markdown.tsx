import { useEffect, useState } from 'react';
import { cn } from "@/lib/utils";

interface MarkdownProps {
  content: string;
  className?: string;
}

export function Markdown({ content, className }: MarkdownProps) {
  const [html, setHtml] = useState('');

  useEffect(() => {
    // Simple Markdown to HTML conversion
    let processedContent = content
      // Headers
      .replace(/^# (.*$)/gm, '<h1 class="text-2xl font-bold mt-6 mb-3">$1</h1>')
      .replace(/^## (.*$)/gm, '<h2 class="text-xl font-bold mt-5 mb-3">$1</h2>')
      .replace(/^### (.*$)/gm, '<h3 class="text-lg font-bold mt-4 mb-2">$1</h3>')
      .replace(/^#### (.*$)/gm, '<h4 class="text-md font-bold mt-3 mb-2">$1</h4>')
      
      // Bold and italic
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      
      // Lists
      .replace(/^\s*\- (.*$)/gm, '<li class="ml-4">$1</li>')
      .replace(/<\/li>\n<li/g, '</li><li')
      .replace(/(<li.*<\/li>)/g, '<ul class="list-disc mb-4 pl-5">$1</ul>')
      
      // Numbered lists
      .replace(/^\s*\d+\. (.*$)/gm, '<li class="ml-4">$1</li>')
      .replace(/<\/li>\n<li/g, '</li><li')
      .replace(/(<li.*<\/li>)/g, '<ol class="list-decimal mb-4 pl-5">$1</ol>')
      
      // Links
      .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a class="text-primary hover:underline" href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      
      // Code blocks
      .replace(/```([\s\S]*?)```/g, '<pre class="bg-muted p-3 rounded-md mb-4 overflow-x-auto"><code>$1</code></pre>')
      
      // Inline code
      .replace(/`([^`]+)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-sm">$1</code>')
      
      // Blockquotes
      .replace(/^\> (.*$)/gm, '<blockquote class="border-l-4 border-primary pl-4 italic text-gray-800 my-4">$1</blockquote>')
      
      // Paragraphs
      .replace(/^(?!<[a-z])/gm, '<p class="mb-4">');

    // Fix duplicated tags and empty paragraphs
    processedContent = processedContent
      .replace(/<\/p><p class="mb-4"><\/p>/g, '</p>')
      .replace(/<p class="mb-4"><\/p>/g, '')
      .replace(/<ul class="list-disc mb-4 pl-5"><ul class="list-disc mb-4 pl-5">/g, '<ul class="list-disc mb-4 pl-5">')
      .replace(/<\/ul><\/ul>/g, '</ul>')
      .replace(/<ol class="list-decimal mb-4 pl-5"><ol class="list-decimal mb-4 pl-5">/g, '<ol class="list-decimal mb-4 pl-5">')
      .replace(/<\/ol><\/ol>/g, '</ol>');

    setHtml(processedContent);
  }, [content]);

  return (
    <div 
      className={cn("prose prose-gray max-w-none", className)} 
      dangerouslySetInnerHTML={{ __html: html }} 
    />
  );
}