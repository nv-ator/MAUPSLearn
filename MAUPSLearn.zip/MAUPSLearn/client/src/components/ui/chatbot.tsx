import React, { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { MessageCircle, X, Send, ChevronUp, Bot, Clock, Timer, Activity, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define message types
type Message = {
  id: string;
  content: string;
  sender: "user" | "bot";
  timestamp: Date;
};

// Define screen time tracking data
type ScreenTimeData = {
  dailyUsage: number; // minutes
  weeklyAverage: number; // minutes
  mostActiveHour: number;
  sessionCount: number;
  lastSessionDuration: number; // minutes
};

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("chat"); // 'chat' or 'wellness'
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "👋 Hi there! I'm your FinTech learning assistant. Ask me anything about financial technology, banking innovations, or our courses! Check out the wellness tab for screen time info.",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [screenTime, setScreenTime] = useState<ScreenTimeData>({
    dailyUsage: 124,
    weeklyAverage: 112, 
    mostActiveHour: 15, // 3 PM
    sessionCount: 8,
    lastSessionDuration: 32
  });
  const [sessionStartTime, setSessionStartTime] = useState<Date | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Scroll to bottom whenever messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input when chat opens and track screen time
  useEffect(() => {
    if (isOpen) {
      // Focus input
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
      
      // Start tracking session
      if (!sessionStartTime) {
        setSessionStartTime(new Date());
      }
    } else if (sessionStartTime) {
      // When chat closes, update screen time
      const sessionDuration = Math.floor((new Date().getTime() - sessionStartTime.getTime()) / 60000) || 1;
      setScreenTime(prev => ({
        ...prev,
        lastSessionDuration: sessionDuration,
        dailyUsage: prev.dailyUsage + sessionDuration,
        sessionCount: prev.sessionCount + 1
      }));
      setSessionStartTime(null);
    }
  }, [isOpen, sessionStartTime]);

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date(),
    };
    
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    
    try {
      // This is where we would call our AI API
      // For now just simulate a response
      setTimeout(() => {
        // Get topic-specific responses
        const botResponse = getBotResponse(input.toLowerCase());
        
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: botResponse,
          sender: "bot",
          timestamp: new Date(),
        };
        
        setMessages((prev) => [...prev, botMessage]);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get a response. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !isLoading) {
      handleSendMessage();
    }
  };

  // Function to get responses based on topics
  const getBotResponse = (userInput: string): string => {
    if (userInput.includes("blockchain") || userInput.includes("bitcoin") || userInput.includes("crypto")) {
      return "Blockchain is a decentralized ledger technology that powers cryptocurrencies like Bitcoin. We have several courses on blockchain fundamentals, cryptocurrency markets, and DeFi (Decentralized Finance). Would you like me to recommend a specific course?";
    } else if (userInput.includes("payment") || userInput.includes("transaction")) {
      return "Digital payment systems are transforming how money moves globally. From mobile wallets to peer-to-peer apps, these technologies prioritize speed, security, and convenience. Check out our 'Modern Payment Systems' course for a deep dive!";
    } else if (userInput.includes("regulation") || userInput.includes("compliance")) {
      return "FinTech regulation varies globally but often focuses on consumer protection, financial stability, and anti-money laundering measures. Our 'FinTech Regulation' course covers key regulatory frameworks like GDPR, PSD2, and more.";
    } else if (userInput.includes("course") || userInput.includes("learn")) {
      return "We offer courses on blockchain, digital banking, algorithmic trading, payment systems, and regulatory technologies. Which topic interests you most? I can provide specific recommendations!";
    } else if (userInput.includes("quiz") || userInput.includes("test")) {
      return "All our courses include interactive quizzes to test your knowledge! These AI-generated quizzes adapt to your learning style and help reinforce key concepts. You can access your quiz history in the dashboard.";
    } else if (userInput.includes("hello") || userInput.includes("hi") || userInput.includes("hey")) {
      return "Hello! How can I help you with your FinTech learning journey today?";
    } else {
      return "That's an interesting question about FinTech! Would you like me to provide information about a specific topic like blockchain, digital banking, or payment systems? Or would you prefer course recommendations?";
    }
  };

  return (
    <div className="fixed bottom-4 left-4 z-50">
      {/* Chat toggle button */}
      {!isOpen && (
        <Button
          onClick={toggleChat}
          className="rounded-full h-20 w-20 bg-black hover:bg-gray-800 text-white shadow-lg flex items-center justify-center"
        >
          <Bot size={42} />
        </Button>
      )}

      {/* Chat window */}
      {isOpen && (
        <Card className="w-80 sm:w-96 h-[500px] bg-black text-white border-gray-800 shadow-xl flex flex-col">
          <CardHeader className="p-3 border-b border-gray-800 flex flex-row justify-between items-center">
            <div className="flex items-center">
              <Bot className="mr-2" size={20} />
              <CardTitle className="text-sm font-medium">FinTech & Wellness Assistant</CardTitle>
            </div>
            <Button variant="ghost" size="icon" onClick={toggleChat} className="h-8 w-8 text-gray-400 hover:text-white hover:bg-gray-800 rounded-full">
              <X size={18} />
            </Button>
          </CardHeader>
          
          <CardContent className="p-0 flex-grow overflow-hidden">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="w-full bg-gray-900 border-b border-gray-800">
                <TabsTrigger 
                  value="chat" 
                  className={`w-1/2 ${activeTab === 'chat' ? 'text-white' : 'text-gray-400'}`}
                >
                  <Bot className="mr-2" size={16} />
                  Chat
                </TabsTrigger>
                <TabsTrigger 
                  value="wellness" 
                  className={`w-1/2 ${activeTab === 'wellness' ? 'text-white' : 'text-gray-400'}`}
                >
                  <Activity className="mr-2" size={16} />
                  Wellness
                </TabsTrigger>
              </TabsList>
              
              {/* Chat Tab Content */}
              <TabsContent value="chat" className="mt-0">
                <ScrollArea className="h-[330px] p-4">
                  <div className="flex flex-col gap-3">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={cn(
                          "flex",
                          message.sender === "user" ? "justify-end" : "justify-start"
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-[80%] rounded-lg p-3",
                            message.sender === "user"
                              ? "bg-blue-600 text-white"
                              : "bg-gray-800 text-white"
                          )}
                        >
                          <p className="text-sm">{message.content}</p>
                          <div className="text-xs mt-1 opacity-70">
                            {message.timestamp.toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                    {isLoading && (
                      <div className="flex justify-start">
                        <div className="bg-gray-800 text-white max-w-[80%] rounded-lg p-3">
                          <div className="flex gap-1">
                            <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></div>
                            <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-75"></div>
                            <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-150"></div>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>
              </TabsContent>
              
              {/* Wellness Tab Content */}
              <TabsContent value="wellness" className="mt-0">
                <ScrollArea className="h-[330px] p-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-3 text-white">Screen Time Tracking</h3>
                      <p className="text-sm text-gray-300 mb-4">
                        Monitoring your screen time can help you maintain a healthy balance between learning and rest.
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Clock className="h-5 w-5 mr-2 text-blue-400" />
                          <span className="text-sm font-medium">Today</span>
                        </div>
                        <p className="text-xl font-bold">{screenTime.dailyUsage} min</p>
                      </div>
                      
                      <div className="bg-gray-800 p-3 rounded-lg">
                        <div className="flex items-center mb-2">
                          <Activity className="h-5 w-5 mr-2 text-green-400" />
                          <span className="text-sm font-medium">Weekly Avg</span>
                        </div>
                        <p className="text-xl font-bold">{screenTime.weeklyAverage} min</p>
                      </div>
                    </div>
                    
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <h4 className="text-sm font-medium mb-3">Current Session</h4>
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-xs text-gray-400">Session Count</p>
                          <p className="text-lg font-bold">{screenTime.sessionCount}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-400">Last Duration</p>
                          <p className="text-lg font-bold">{screenTime.lastSessionDuration} min</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-400">Active Hour</p>
                          <p className="text-lg font-bold">{screenTime.mostActiveHour}:00</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-800 p-4 rounded-lg">
                      <h4 className="text-sm font-medium mb-3">Wellness Tips</h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start">
                          <Brain className="h-4 w-4 mr-2 text-purple-400 mt-0.5" />
                          <span>Take a 5-minute break every 25 minutes of learning.</span>
                        </li>
                        <li className="flex items-start">
                          <Timer className="h-4 w-4 mr-2 text-yellow-400 mt-0.5" />
                          <span>Limit screen time to 2 hours per day for optimal retention.</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </CardContent>
          
          {/* Only show input when in chat tab */}
          {activeTab === "chat" && (
            <CardFooter className="p-3 border-t border-gray-800">
              <div className="flex w-full items-center gap-2">
                <Input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Type your message..."
                  className="flex-grow bg-gray-800 border-gray-700 text-white placeholder:text-gray-400 focus-visible:ring-blue-600"
                  disabled={isLoading}
                />
                <Button
                  size="icon"
                  disabled={isLoading || !input.trim()}
                  onClick={handleSendMessage}
                  className="h-10 w-10 bg-blue-600 hover:bg-blue-700 rounded-full"
                >
                  <Send size={18} className={isLoading ? "animate-pulse" : ""} />
                </Button>
              </div>
            </CardFooter>
          )}
        </Card>
      )}
    </div>
  );
}