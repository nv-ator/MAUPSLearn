import { useEffect, useRef, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Pause, Volume2, VolumeX, Maximize, Settings } from "lucide-react";

declare global {
  interface Window {
    onYouTubeIframeAPIReady: () => void;
    YT: {
      Player: new (elementId: string, options: any) => YTPlayer;
      PlayerState: {
        PLAYING: number;
        PAUSED: number;
        ENDED: number;
      };
    };
  }
}

interface YTPlayer {
  playVideo(): void;
  pauseVideo(): void;
  getCurrentTime(): number;
  getDuration(): number;
  seekTo(seconds: number): void;
  getPlayerState(): number;
  destroy(): void;
  mute(): void;
  unMute(): void;
  isMuted(): boolean;
}

interface YouTubePlayerProps {
  videoId: string;
  title?: string;
  onProgress?: (progress: number) => void;
  onVideoEnd?: () => void;
  className?: string;
}

export function YouTubePlayer({
  videoId,
  title,
  onProgress,
  onVideoEnd,
  className,
}: YouTubePlayerProps) {
  const [player, setPlayer] = useState<YTPlayer | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const playerInstanceRef = useRef<YTPlayer | null>(null);
  const progressInterval = useRef<number | null>(null);

  // Format time (seconds) to mm:ss format
  const formatTime = (seconds: number) => {
    const min = Math.floor(seconds / 60);
    const sec = Math.floor(seconds % 60);
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  useEffect(() => {
    // Load YouTube IFrame API
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    if (firstScriptTag.parentNode) {
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    }

    // Initialize player when API is ready
    window.onYouTubeIframeAPIReady = () => {
      if (playerRef.current) {
        try {
          const ytPlayer = new window.YT.Player(`youtube-player-${videoId}`, {
            videoId,
            playerVars: {
              autoplay: 0,
              modestbranding: 1,
              rel: 0,
              showinfo: 0,
              fs: 1,
              playsinline: 1,
            },
            events: {
              onReady: (event) => {
                setPlayer(event.target);
                playerInstanceRef.current = event.target;
                setDuration(event.target.getDuration());
                setLoading(false);
              },
              onStateChange: (event) => {
                const playerState = event.data;
                if (playerState === window.YT.PlayerState.PLAYING) {
                  setIsPlaying(true);
                  startProgressTracking();
                } else if (playerState === window.YT.PlayerState.PAUSED) {
                  setIsPlaying(false);
                  stopProgressTracking();
                } else if (playerState === window.YT.PlayerState.ENDED) {
                  setIsPlaying(false);
                  stopProgressTracking();
                  if (onVideoEnd) onVideoEnd();
                }
              },
              onError: () => {
                setError("Error loading video. Please try again later.");
                setLoading(false);
              }
            }
          });
          
          setPlayer(ytPlayer);
          playerInstanceRef.current = ytPlayer;
        } catch (err) {
          console.error("Error initializing YouTube player:", err);
          setError("Failed to initialize video player.");
          setLoading(false);
        }
      }
    };

    // Cleanup
    return () => {
      stopProgressTracking();
      if (playerInstanceRef.current) {
        playerInstanceRef.current.destroy();
      }
    };
  }, [videoId, onVideoEnd]);

  const startProgressTracking = () => {
    stopProgressTracking();
    progressInterval.current = window.setInterval(() => {
      if (playerInstanceRef.current) {
        const currentSeconds = playerInstanceRef.current.getCurrentTime();
        const videoDuration = playerInstanceRef.current.getDuration();
        setCurrentTime(currentSeconds);
        
        if (onProgress && videoDuration) {
          const progressPercent = (currentSeconds / videoDuration) * 100;
          onProgress(progressPercent);
        }
      }
    }, 1000);
  };

  const stopProgressTracking = () => {
    if (progressInterval.current) {
      clearInterval(progressInterval.current);
      progressInterval.current = null;
    }
  };

  const togglePlayPause = () => {
    if (!player) return;
    
    if (isPlaying) {
      player.pauseVideo();
    } else {
      player.playVideo();
    }
  };

  const toggleMute = () => {
    if (!player) return;
    
    if (isMuted) {
      player.unMute();
      setIsMuted(false);
    } else {
      player.mute();
      setIsMuted(true);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!player || !duration) return;
    
    const seekTime = (parseInt(e.target.value) / 100) * duration;
    player.seekTo(seekTime);
    setCurrentTime(seekTime);
  };

  return (
    <div className={`relative rounded-lg overflow-hidden aspect-video ${className}`}>
      {loading ? (
        <Skeleton className="w-full h-full" />
      ) : error ? (
        <div className="w-full h-full flex items-center justify-center bg-gray-800 text-white">
          <p>{error}</p>
        </div>
      ) : (
        <>
          <div className="w-full h-full" ref={playerRef}>
            <div id={`youtube-player-${videoId}`} />
          </div>
          
          {/* Custom controls overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end opacity-0 hover:opacity-100 transition-opacity">
            <div className="p-4">
              {title && (
                <h3 className="text-white font-medium mb-2">{title}</h3>
              )}
              
              <div className="flex items-center mb-2">
                <button 
                  className="p-1.5 bg-white/20 rounded-full text-white hover:bg-white/30"
                  onClick={togglePlayPause}
                  aria-label={isPlaying ? "Pause" : "Play"}
                >
                  {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                </button>
                
                <div className="flex-1 mx-2">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={(currentTime / (duration || 1)) * 100}
                    onChange={handleSeek}
                    className="w-full accent-primary-600 h-1 bg-white/30 rounded-full"
                  />
                </div>
                
                <div className="text-white text-xs mr-2">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </div>
                
                <button 
                  className="p-1.5 bg-white/20 rounded-full text-white hover:bg-white/30 mr-2"
                  onClick={toggleMute}
                  aria-label={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                </button>
                
                <button 
                  className="p-1.5 bg-white/20 rounded-full text-white hover:bg-white/30 mr-2"
                  aria-label="Playback speed"
                >
                  <Settings size={16} />
                </button>
                
                <button 
                  className="p-1.5 bg-white/20 rounded-full text-white hover:bg-white/30"
                  aria-label="Full screen"
                >
                  <Maximize size={16} />
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
