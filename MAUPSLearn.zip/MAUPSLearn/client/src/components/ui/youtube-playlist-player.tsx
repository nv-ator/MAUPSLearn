import { useState, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { Button } from './button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './card';
import { Skeleton } from './skeleton';

interface PlaylistVideo {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  position: number;
  duration?: number;
}

interface PlaylistDetails {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  itemCount: number;
  videos: PlaylistVideo[];
}

interface YoutubePlaylistPlayerProps {
  playlistId: string;
  autoplay?: boolean;
  maxVideos?: number;
  onVideoSelect?: (videoId: string, videoTitle?: string) => void;
}

// Helper function to format seconds into a readable duration
function formatDuration(seconds: number): string {
  if (!seconds) return 'N/A';
  
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  } else {
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }
}

export function YoutubePlaylistPlayer({
  playlistId,
  autoplay = false,
  maxVideos = 10,
  onVideoSelect
}: YoutubePlaylistPlayerProps) {
  const [playlistDetails, setPlaylistDetails] = useState<PlaylistDetails | null>(null);
  const [currentVideoId, setCurrentVideoId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPlaylistDetails = async () => {
      try {
        setLoading(true);
        const playlistData = await apiRequest<PlaylistDetails>(
          `/api/youtube/playlist/${playlistId}?maxResults=${maxVideos}`
        );
        setPlaylistDetails(playlistData);
        
        // Set the first video as current if none is selected
        if (!currentVideoId && playlistData.videos.length > 0) {
          setCurrentVideoId(playlistData.videos[0].id);
        }
        
        setLoading(false);
      } catch (err) {
        console.error('Error fetching playlist details:', err);
        setError('Failed to load playlist. Please try again later.');
        setLoading(false);
      }
    };

    if (playlistId && loading) {
      fetchPlaylistDetails();
    }
  }, [playlistId, maxVideos, loading, currentVideoId]);

  const handleVideoSelect = (videoId: string) => {
    setCurrentVideoId(videoId);
    if (onVideoSelect) {
      // Find the current video to pass the title
      const currentVideo = playlistDetails?.videos.find(v => v.id === videoId);
      onVideoSelect(videoId, currentVideo?.title);
    }
  };

  if (loading) {
    return (
      <div className="w-full">
        <Skeleton className="w-full h-[360px] mb-4" />
        <div className="flex flex-col gap-2">
          <Skeleton className="w-full h-16" />
          <Skeleton className="w-full h-16" />
          <Skeleton className="w-full h-16" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Error</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-red-500">{error}</p>
        </CardContent>
        <CardFooter>
          <Button onClick={() => { setLoading(true); setError(null); }}>Try Again</Button>
        </CardFooter>
      </Card>
    );
  }

  if (!playlistDetails || playlistDetails.videos.length === 0) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>No Videos Found</CardTitle>
        </CardHeader>
        <CardContent>
          <p>This playlist doesn't contain any videos or the playlist ID might be incorrect.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="md:col-span-2">
        {currentVideoId && (
          <div className="aspect-video w-full">
            <iframe
              className="w-full h-full"
              src={`https://www.youtube.com/embed/${currentVideoId}?autoplay=${autoplay ? 1 : 0}`}
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        )}
        {currentVideoId && playlistDetails.videos && (
          <div className="mt-4">
            <h2 className="text-xl font-bold">
              {playlistDetails.videos.find(v => v.id === currentVideoId)?.title}
            </h2>
            <p className="text-sm text-gray-500 mt-2">
              {playlistDetails.videos.find(v => v.id === currentVideoId)?.description.substring(0, 200)}
              {(playlistDetails.videos.find(v => v.id === currentVideoId)?.description.length || 0) > 200 ? '...' : ''}
            </p>
          </div>
        )}
      </div>

      <div className="overflow-y-auto max-h-[600px] border rounded-md">
        <div className="p-4 bg-secondary mb-2 sticky top-0">
          <h3 className="font-bold">Playlist: {playlistDetails.title}</h3>
          <p className="text-sm text-muted-foreground">{playlistDetails.itemCount} videos</p>
        </div>
        <div className="space-y-2 p-2">
          {playlistDetails.videos.map((video) => (
            <div 
              key={video.id}
              className={`p-2 cursor-pointer flex gap-2 rounded-md hover:bg-secondary/50 ${currentVideoId === video.id ? 'bg-secondary' : ''}`}
              onClick={() => handleVideoSelect(video.id)}
            >
              <img 
                src={video.thumbnail} 
                alt={video.title}
                className="w-24 h-16 object-cover rounded-md"
              />
              <div className="flex-1 flex flex-col justify-center">
                <h4 className="text-sm font-medium line-clamp-2">{video.title}</h4>
                <span className="text-xs text-muted-foreground">
                  {video.position + 1}. {video.duration ? formatDuration(video.duration) : 'Loading...'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}