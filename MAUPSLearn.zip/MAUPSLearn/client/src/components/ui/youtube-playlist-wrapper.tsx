import { useState, useEffect } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { YoutubePlaylistPlayer } from './youtube-playlist-player';
import { Button } from './button';
import { Input } from './input';
import { Label } from './label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './card';
import { Alert, AlertDescription, AlertTitle } from './alert';
import { AlertCircle, Youtube } from 'lucide-react';

interface YoutubePlaylistWrapperProps {
  initialPlaylistId?: string;
  initialPlaylistUrl?: string;
  autoplay?: boolean;
  maxVideos?: number;
  showUrlInput?: boolean;
  onVideoSelect?: (videoId: string, videoTitle?: string) => void;
}

export function YoutubePlaylistWrapper({
  initialPlaylistId,
  initialPlaylistUrl,
  autoplay = false,
  maxVideos = 10,
  showUrlInput = true,
  onVideoSelect
}: YoutubePlaylistWrapperProps) {
  const [playlistId, setPlaylistId] = useState<string | null>(initialPlaylistId || null);
  const [playlistUrl, setPlaylistUrl] = useState(initialPlaylistUrl || '');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialPlaylistId) {
      setPlaylistId(initialPlaylistId);
    } else if (initialPlaylistUrl) {
      extractPlaylistIdFromUrl(initialPlaylistUrl);
    }
  }, [initialPlaylistId, initialPlaylistUrl]);

  const extractPlaylistIdFromUrl = async (url: string) => {
    if (!url) return;
    
    try {
      setLoading(true);
      setError(null);
      
      const result = await apiRequest<{ playlistId: string }>(
        `/api/youtube/extract-playlist-id?url=${encodeURIComponent(url)}`
      );
      setPlaylistId(result.playlistId);
      setLoading(false);
    } catch (err) {
      console.error('Error extracting playlist ID:', err);
      setError('Could not extract playlist ID from the provided URL. Please check the URL and try again.');
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    extractPlaylistIdFromUrl(playlistUrl);
  };

  if (!playlistId && !showUrlInput) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Playlist Not Found</CardTitle>
        </CardHeader>
        <CardContent>
          <p>No playlist ID or URL was provided.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full">
      {showUrlInput && (
        <div className="mb-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="playlist-url">YouTube Playlist URL</Label>
              <div className="flex gap-2">
                <Input
                  id="playlist-url"
                  type="text"
                  placeholder="https://www.youtube.com/playlist?list=XXXXXXXXXX"
                  value={playlistUrl}
                  onChange={(e) => setPlaylistUrl(e.target.value)}
                  className="flex-1"
                />
                <Button 
                  type="submit" 
                  disabled={loading || !playlistUrl}
                  variant="secondary"
                >
                  <Youtube className="mr-2 h-4 w-4" />
                  Load Playlist
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Enter a YouTube playlist URL to load its contents
              </p>
            </div>
          </form>
        </div>
      )}

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {playlistId ? (
        <YoutubePlaylistPlayer 
          playlistId={playlistId} 
          autoplay={autoplay} 
          maxVideos={maxVideos}
          onVideoSelect={onVideoSelect}
        />
      ) : (
        <Card className="w-full min-h-[200px] flex items-center justify-center">
          <CardContent>
            <div className="text-center">
              <Youtube className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">
                Enter a YouTube playlist URL above to start learning
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}