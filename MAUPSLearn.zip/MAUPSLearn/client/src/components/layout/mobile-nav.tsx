import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Video, HelpCircle, Trophy, User, Brain, Youtube, Sparkles, FileText } from "lucide-react";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/playlist", label: "Playlists", icon: Youtube },
    { href: "/quiz-generator", label: "AI Quiz", icon: Sparkles },
    { href: "/ai-notes-maker", label: "AI Notes", icon: FileText },
    { href: "/profile", label: "Profile", icon: User },
  ];

  return (
    <div className="md:hidden fixed bottom-0 inset-x-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 z-10">
      <div className="grid grid-cols-5 h-16">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link 
              key={item.href} 
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center",
                isActive 
                  ? "text-primary-600 dark:text-primary-400" 
                  : "text-gray-500 dark:text-gray-400"
              )}
            >
              <item.icon className="h-5 w-5" />
              <span className="text-xs mt-1">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
