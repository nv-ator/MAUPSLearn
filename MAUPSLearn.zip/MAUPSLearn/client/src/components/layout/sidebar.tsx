import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Home,
  Video,
  HelpCircle,
  Trophy,
  Users,
  Settings,
  BarChart3,
  Brain,
  Youtube,
  Sparkles,
  FileText
} from "lucide-react";


export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/playlist", label: "YouTube Playlists", icon: Youtube },
    { href: "/quiz-generator", label: "AI Quiz Generator", icon: Sparkles },
    { href: "/ai-notes-maker", label: "AI Notes Maker", icon: FileText },
    { href: "/achievements", label: "Achievements", icon: Trophy },
    { href: "/community", label: "Community", icon: Users },
    { href: "/wellness", label: "Mental Wellness", icon: Brain },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <aside className="hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 z-10">
      <div className="flex flex-col flex-grow overflow-y-auto border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 pt-5">
        <div className="flex items-center flex-shrink-0 px-4 mb-5">
          <div className="flex items-center">
            <BarChart3 className="text-primary-500 text-2xl mr-2" />
            <span className="font-bold text-lg tracking-tight">FinLearn</span>
          </div>
        </div>

        <div className="mt-5 flex-grow flex flex-col">
          <nav className="flex-1 px-2 pb-4 space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.href;
              return (
                <Link 
                  key={item.href} 
                  href={item.href}
                  className={cn(
                    "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors",
                    isActive 
                      ? "bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300" 
                      : "text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700"
                  )}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </div>


      </div>
    </aside>
  );
}