// User Types
export interface User {
  id: number;
  username: string;
  displayName: string;
  avatar?: string;
  points: number;
  streak: number;
  level: number;
}

// Course Types
export interface Course {
  id: number;
  title: string;
  description: string;
  playlistId: string;
  thumbnail?: string;
  difficulty: string;
  category: string;
  totalVideos: number;
}

// Video Types
export interface Video {
  id: number;
  courseId: number;
  videoId: string; // YouTube video ID
  title: string;
  description?: string;
  thumbnail?: string;
  duration: number;
  position: number;
}

// Progress Types
export interface Progress {
  id: number;
  userId: number;
  courseId: number;
  videoId: number;
  completed: boolean;
  watchTime: number;
  lastWatched?: Date;
}

// Quiz Types
export interface Question {
  question: string;
  options: string[];
  correctOptionIndex: number;
}

export interface Quiz {
  id: number;
  videoId: number;
  questions: Question[];
  createdAt: Date;
}

export interface QuizResult {
  id: number;
  userId: number;
  quizId: number;
  score: number;
  totalQuestions: number;
  completedAt: Date;
}

// Challenge Types
export interface Challenge {
  id: number;
  title: string;
  description: string;
  startDate: Date | string;
  endDate: Date | string;
  pointsReward: number;
  isTeamChallenge: boolean;
}

export interface ChallengeParticipant {
  id: number;
  challengeId: number;
  userId: number;
  teamId?: number;
  progress: number;
  completed: boolean;
  joinedAt: Date | string;
}

// API Response Types
export interface LeaderboardEntry extends Omit<User, 'password'> {}

export interface ApiError {
  message: string;
}
