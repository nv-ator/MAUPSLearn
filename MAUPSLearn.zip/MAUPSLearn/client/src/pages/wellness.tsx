import React, { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, Timer, Activity, Brain, Calendar, Coffee, Moon, BarChart } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

// Define screen time tracking data
type ScreenTimeData = {
  dailyUsage: number; // minutes
  weeklyAverage: number; // minutes
  mostActiveHour: number;
  sessionCount: number;
  lastSessionDuration: number; // minutes
};

export default function Wellness() {
  const [screenTime, setScreenTime] = useState<ScreenTimeData>({
    dailyUsage: 124,
    weeklyAverage: 112, 
    mostActiveHour: 15, // 3 PM
    sessionCount: 8,
    lastSessionDuration: 32
  });
  
  // Get mental wellness tips
  const { data: wellnessTips } = useQuery({
    queryKey: ['wellnessTips'],
    queryFn: async () => {
      // Mock data - in a real app, this would come from an API
      return [
        {
          id: 1,
          title: "Take regular breaks",
          description: "Take a 5-minute break every 25 minutes of learning for optimal focus.",
          icon: "break"
        },
        {
          id: 2,
          title: "Limit screen time",
          description: "Limit daily screen time to 2 hours for better retention and eye health.",
          icon: "screen"
        },
        {
          id: 3,
          title: "Stay hydrated",
          description: "Drink at least 8 glasses of water daily to maintain cognitive function.",
          icon: "water"
        },
        {
          id: 4, 
          title: "Practice mindfulness",
          description: "Take 10 minutes each day to practice mindfulness for better learning outcomes.",
          icon: "mindful"
        }
      ];
    },
    initialData: []
  });

  function getIconForTip(iconType: string) {
    switch (iconType) {
      case 'break':
        return <Coffee className="h-5 w-5 text-blue-400" />;
      case 'screen':
        return <Timer className="h-5 w-5 text-yellow-400" />;
      case 'water':
        return <Activity className="h-5 w-5 text-green-400" />;
      case 'mindful':
        return <Brain className="h-5 w-5 text-purple-400" />;
      default:
        return <Brain className="h-5 w-5 text-purple-400" />;
    }
  }
  
  return (
    <div className="container mx-auto py-6 px-4 md:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Mental Wellness</h1>
        <p className="text-gray-500 dark:text-gray-400">
          Track your screen time and manage your mental health while learning.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Screen Time Analytics</CardTitle>
              <CardDescription>
                Monitor your usage patterns to maintain a healthy balance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="bg-card p-4 rounded-lg border">
                  <div className="flex items-center mb-2">
                    <Clock className="h-5 w-5 mr-2 text-blue-400" />
                    <span className="text-sm font-medium">Today's Usage</span>
                  </div>
                  <p className="text-2xl font-bold">{screenTime.dailyUsage} min</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {screenTime.dailyUsage > 180 ? "Consider taking a longer break" : "Looking good!"}
                  </p>
                </div>
                
                <div className="bg-card p-4 rounded-lg border">
                  <div className="flex items-center mb-2">
                    <Activity className="h-5 w-5 mr-2 text-green-400" />
                    <span className="text-sm font-medium">Weekly Average</span>
                  </div>
                  <p className="text-2xl font-bold">{screenTime.weeklyAverage} min</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Per day over the last 7 days
                  </p>
                </div>
                
                <div className="bg-card p-4 rounded-lg border">
                  <div className="flex items-center mb-2">
                    <BarChart className="h-5 w-5 mr-2 text-violet-400" />
                    <span className="text-sm font-medium">Session Count</span>
                  </div>
                  <p className="text-2xl font-bold">{screenTime.sessionCount}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Most active at {screenTime.mostActiveHour}:00
                  </p>
                </div>
              </div>
              
              <div className="bg-card p-6 rounded-lg border">
                <h3 className="text-lg font-medium mb-4">Usage Pattern</h3>
                <div className="h-[200px] flex items-end justify-between">
                  {/* Simulated graph bars */}
                  {Array.from({length: 7}).map((_, i) => {
                    const height = 30 + Math.random() * 70;
                    return (
                      <div key={i} className="flex flex-col items-center">
                        <div 
                          className="w-8 bg-blue-500 rounded-t"
                          style={{height: `${height}%`}}
                        ></div>
                        <span className="text-xs mt-2">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Wellness Tips</CardTitle>
              <CardDescription>
                Improve your learning experience with these recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {wellnessTips.map((tip) => (
                  <div key={tip.id} className="flex p-4 bg-card rounded-lg border">
                    <div className="mr-4 mt-0.5">
                      {getIconForTip(tip.icon)}
                    </div>
                    <div>
                      <h4 className="text-sm font-medium">{tip.title}</h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {tip.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Last Session</CardTitle>
              <CardDescription>
                Details about your most recent activity
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-xs text-muted-foreground">Duration</p>
                  <p className="text-lg font-bold">{screenTime.lastSessionDuration} min</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Started</p>
                  <p className="text-lg font-bold">14:30</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Focus</p>
                  <p className="text-lg font-bold">92%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}