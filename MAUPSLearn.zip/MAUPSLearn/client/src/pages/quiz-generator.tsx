import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Loader2, Brain, Award, CheckCircle2 } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Question } from "@shared/schema";

export default function QuizGenerator() {
  const { toast } = useToast();
  const [topic, setTopic] = useState<string>("");
  const [content, setContent] = useState<string>("");
  const [numQuestions, setNumQuestions] = useState<number>(5);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [showResults, setShowResults] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);

  const handleGenerate = async () => {
    if (!topic) {
      toast({
        title: "Topic Required",
        description: "Please enter a financial topic for your quiz.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setQuestions([]);
    setUserAnswers([]);
    setShowResults(false);

    try {
      const response = await apiRequest<{ questions: Question[] }>("/api/gemini/financial-quiz", {
        method: "POST",
        body: JSON.stringify({
          topic,
          content: content || undefined,
          numQuestions,
        }),
      });

      if (response && response.questions && Array.isArray(response.questions)) {
        setQuestions(response.questions);
        // Initialize user answers array with -1 (unanswered)
        setUserAnswers(new Array(response.questions.length).fill(-1));
      } else {
        throw new Error("Invalid response format");
      }
    } catch (error) {
      console.error("Error generating quiz:", error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate quiz. Please try again with a different topic.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAnswerSelect = (questionIndex: number, optionIndex: number) => {
    const newAnswers = [...userAnswers];
    newAnswers[questionIndex] = optionIndex;
    setUserAnswers(newAnswers);
  };

  const handleSubmit = () => {
    // Calculate score
    let correctCount = 0;
    for (let i = 0; i < questions.length; i++) {
      if (userAnswers[i] === questions[i].correctOptionIndex) {
        correctCount++;
      }
    }
    setScore(correctCount);
    setShowResults(true);

    // Show toast with score
    toast({
      title: "Quiz Submitted",
      description: `You scored ${correctCount} out of ${questions.length}!`,
      variant: correctCount / questions.length >= 0.7 ? "default" : "destructive",
    });
  };

  const handleReset = () => {
    setQuestions([]);
    setUserAnswers([]);
    setShowResults(false);
    setScore(0);
  };

  const isAllAnswered = userAnswers.length > 0 && !userAnswers.includes(-1);

  return (
    <div className="container py-6">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6 flex items-center">
          <Brain className="mr-2 h-8 w-8 text-primary" />
          <span className="bg-gradient-to-r from-primary to-primary-600 bg-clip-text text-transparent">
            Financial Quiz Generator
          </span>
        </h1>
        <p className="text-muted-foreground mb-6">
          Generate custom quizzes on any financial topic using Google's Gemini AI. Optionally, provide additional content for more specific questions.
        </p>

        {questions.length === 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>Create a New Quiz</CardTitle>
              <CardDescription>
                Enter a financial topic to generate questions about
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="topic">Financial Topic</Label>
                <Input
                  id="topic"
                  placeholder="e.g., Stock Market, Cryptocurrency, Personal Finance"
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="content">
                  Additional Content (Optional)
                </Label>
                <Textarea
                  id="content"
                  placeholder="Paste article text, financial concepts, or specific information you want the quiz to cover"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={5}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="numQuestions">Number of Questions</Label>
                <Input
                  id="numQuestions"
                  type="number"
                  min={1}
                  max={10}
                  value={numQuestions}
                  onChange={(e) => setNumQuestions(parseInt(e.target.value) || 5)}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleGenerate} 
                disabled={isGenerating || !topic} 
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Quiz...
                  </>
                ) : (
                  "Generate Quiz"
                )}
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold">
                Quiz: {topic}
              </h2>
              <Button variant="outline" onClick={handleReset}>
                Create New Quiz
              </Button>
            </div>

            {questions.map((question, qIndex) => (
              <Card key={qIndex} className={showResults ? (userAnswers[qIndex] === question.correctOptionIndex ? "border-green-500" : "border-red-500") : ""}>
                <CardHeader>
                  <CardTitle className="flex items-start gap-2">
                    <span className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0">
                      {qIndex + 1}
                    </span>
                    <span>{question.question}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup 
                    value={userAnswers[qIndex]?.toString() || ""} 
                    onValueChange={(value) => handleAnswerSelect(qIndex, parseInt(value))}
                    disabled={showResults}
                  >
                    {question.options.map((option, oIndex) => (
                      <div 
                        key={oIndex} 
                        className={`flex items-center space-x-2 p-3 rounded-md border ${
                          showResults 
                            ? oIndex === question.correctOptionIndex
                              ? "border-green-500 bg-green-50 dark:bg-green-950/20"
                              : userAnswers[qIndex] === oIndex
                                ? "border-red-500 bg-red-50 dark:bg-red-950/20"
                                : "border-gray-200 dark:border-gray-800"
                            : "border-gray-200 dark:border-gray-800"
                        }`}
                      >
                        <RadioGroupItem value={oIndex.toString()} id={`q${qIndex}-o${oIndex}`} />
                        <Label 
                          htmlFor={`q${qIndex}-o${oIndex}`}
                          className="flex-1 cursor-pointer"
                        >
                          {option}
                        </Label>
                        {showResults && oIndex === question.correctOptionIndex && (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        )}
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>
            ))}

            {showResults ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="mr-2 h-5 w-5 text-primary" />
                    Quiz Results
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-4">
                    <div className="text-5xl font-bold mb-2">
                      {score} / {questions.length}
                    </div>
                    <p className="text-lg text-muted-foreground">
                      {score === questions.length
                        ? "Perfect score! Excellent work!"
                        : score / questions.length >= 0.7
                        ? "Great job! You've mastered this topic."
                        : "Keep studying to improve your knowledge."}
                    </p>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button onClick={handleReset} className="w-full">
                    Create New Quiz
                  </Button>
                </CardFooter>
              </Card>
            ) : (
              <Button 
                onClick={handleSubmit} 
                disabled={!isAllAnswered} 
                className="w-full"
              >
                Submit Answers
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}