import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { User } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Settings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const displayNameRef = useRef<HTMLInputElement>(null);
  const bioRef = useRef<HTMLTextAreaElement>(null);
  
  // State for notification and privacy settings
  const [emailNotifs, setEmailNotifs] = useState({
    courseUpdates: true,
    challenges: true,
    community: false
  });
  
  const [appNotifs, setAppNotifs] = useState({
    quizReminders: true,
    streakReminders: true
  });
  
  const [privacySettings, setPrivacySettings] = useState({
    showProfile: true,
    shareProgress: true,
    personalizedContent: true,
    analytics: true
  });
  
  // User data query
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/users/1'],
    enabled: true,
  });

  // Update profile mutation
  const { mutate: updateProfile, isPending: isSavingProfile } = useMutation({
    mutationFn: async (profileData: { displayName: string, bio?: string }) => {
      const response = await apiRequest(
        'PATCH',
        `/api/users/1`,
        profileData
      );
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/users/1'] });
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating profile",
        description: error.message || "Something went wrong",
        variant: "destructive"
      });
    }
  });

  // Save notifications preference mutation
  const { mutate: updatePreferences, isPending: isSavingPreferences } = useMutation({
    mutationFn: async (settings: any) => {
      const response = await apiRequest(
        'PATCH',
        `/api/users/1`,
        { preferences: settings }
      );
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Settings updated",
        description: "Your preferences have been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating settings",
        description: error.message || "Something went wrong",
        variant: "destructive"
      });
    }
  });

  const handleSaveProfile = async () => {
    if (!displayNameRef.current) return;
    
    updateProfile({
      displayName: displayNameRef.current.value,
      bio: bioRef.current?.value
    });
  };

  const handleSaveNotifications = async () => {
    updatePreferences({
      notifications: {
        email: emailNotifs,
        app: appNotifs
      }
    });
  };
  
  const handleSavePrivacy = async () => {
    updatePreferences({
      privacy: privacySettings
    });
  };

  if (isLoading) {
    return (
      <div className="container max-w-6xl py-6 flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container max-w-6xl py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your account settings and preferences</p>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your personal information and how your profile appears to others
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                    {user?.avatar ? (
                      <img src={user.avatar} alt={user.displayName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="text-4xl">{user?.displayName?.charAt(0)}</div>
                    )}
                  </div>
                  <div>
                    <Button variant="outline" size="sm">
                      Change avatar
                    </Button>
                  </div>
                </div>

                <div className="grid gap-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input id="username" defaultValue={user?.username} disabled />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="displayName">Display Name</Label>
                      <Input 
                        id="displayName" 
                        defaultValue={user?.displayName} 
                        ref={displayNameRef}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <textarea
                      id="bio"
                      ref={bioRef}
                      className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm"
                      placeholder="Write a short bio about yourself"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleSaveProfile} disabled={isSavingProfile}>
                {isSavingProfile && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure how and when you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Email Notifications</h3>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="course-updates">Course updates</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive emails about new content in your enrolled courses
                      </p>
                    </div>
                    <Switch 
                      id="course-updates" 
                      checked={emailNotifs.courseUpdates}
                      onCheckedChange={(checked) => setEmailNotifs({...emailNotifs, courseUpdates: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="challenges">Challenges</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive emails about new challenges and their results
                      </p>
                    </div>
                    <Switch 
                      id="challenges" 
                      checked={emailNotifs.challenges}
                      onCheckedChange={(checked) => setEmailNotifs({...emailNotifs, challenges: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="community">Community activity</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive emails about forum posts and community events
                      </p>
                    </div>
                    <Switch 
                      id="community" 
                      checked={emailNotifs.community}
                      onCheckedChange={(checked) => setEmailNotifs({...emailNotifs, community: checked})}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">In-app Notifications</h3>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="quiz-reminders">Quiz reminders</Label>
                      <p className="text-sm text-muted-foreground">
                        Get notifications when you have quizzes to complete
                      </p>
                    </div>
                    <Switch 
                      id="quiz-reminders" 
                      checked={appNotifs.quizReminders}
                      onCheckedChange={(checked) => setAppNotifs({...appNotifs, quizReminders: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="streak-reminders">Streak reminders</Label>
                      <p className="text-sm text-muted-foreground">
                        Get reminders to maintain your learning streak
                      </p>
                    </div>
                    <Switch 
                      id="streak-reminders" 
                      checked={appNotifs.streakReminders}
                      onCheckedChange={(checked) => setAppNotifs({...appNotifs, streakReminders: checked})}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleSaveNotifications} disabled={isSavingPreferences}>
                {isSavingPreferences && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save preferences
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Privacy Settings</CardTitle>
              <CardDescription>
                Control your privacy preferences and data usage
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Profile Visibility</h3>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="show-profile">Show profile on leaderboards</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow your profile to appear on public leaderboards
                      </p>
                    </div>
                    <Switch 
                      id="show-profile" 
                      checked={privacySettings.showProfile}
                      onCheckedChange={(checked) => setPrivacySettings({...privacySettings, showProfile: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="share-progress">Share learning progress</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow others to see your course completion status
                      </p>
                    </div>
                    <Switch 
                      id="share-progress" 
                      checked={privacySettings.shareProgress}
                      onCheckedChange={(checked) => setPrivacySettings({...privacySettings, shareProgress: checked})}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">Data Usage</h3>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="personalized-content">Personalized content</Label>
                      <p className="text-sm text-muted-foreground">
                        Allow us to recommend courses based on your activity
                      </p>
                    </div>
                    <Switch 
                      id="personalized-content" 
                      checked={privacySettings.personalizedContent}
                      onCheckedChange={(checked) => setPrivacySettings({...privacySettings, personalizedContent: checked})}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="analytics">Usage analytics</Label>
                      <p className="text-sm text-muted-foreground">
                        Help us improve by sharing anonymous usage data
                      </p>
                    </div>
                    <Switch 
                      id="analytics" 
                      checked={privacySettings.analytics}
                      onCheckedChange={(checked) => setPrivacySettings({...privacySettings, analytics: checked})}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline">Download your data</Button>
              <Button onClick={handleSavePrivacy} disabled={isSavingPreferences}>
                {isSavingPreferences && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save settings
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}