import { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, BookOpen, FileText, Link as LinkIcon, RefreshCw, Youtube } from 'lucide-react';
import { Markdown } from '@/components/ui/markdown';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function AINotesGenerator() {
  const [title, setTitle] = useState<string>('');
  const [content, setContent] = useState<string>('');
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [videoId, setVideoId] = useState<string | null>(null);
  const [notes, setNotes] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('text');

  // Extract video ID from YouTube URL
  const extractVideoId = (url: string) => {
    try {
      const urlObj = new URL(url);
      const params = new URLSearchParams(urlObj.search);
      
      if (urlObj.hostname.includes('youtube.com')) {
        if (urlObj.pathname === '/watch') {
          return params.get('v');
        } else if (urlObj.pathname.startsWith('/embed/')) {
          return urlObj.pathname.split('/embed/')[1];
        }
      } else if (urlObj.hostname === 'youtu.be') {
        return urlObj.pathname.substring(1);
      }
      
      return null;
    } catch (err) {
      console.error('Invalid URL:', err);
      return null;
    }
  };

  const validateYoutubeUrl = () => {
    const id = extractVideoId(youtubeUrl);
    if (id) {
      setVideoId(id);
      return true;
    } else {
      setError('Invalid YouTube URL. Please enter a valid URL (e.g., https://www.youtube.com/watch?v=VIDEO_ID)');
      setVideoId(null);
      return false;
    }
  };

  const generateNotesFromText = async () => {
    if (!title || !content) {
      toast({
        title: "Missing information",
        description: "Please provide a title and content to generate notes from.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      // Use the financial quiz endpoint since it accepts any content
      const result = await apiRequest<{ questions: any }>('/api/gemini/financial-quiz', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          topic: title,
          content: `Please format this as comprehensive notes with proper markdown formatting rather than a quiz: ${content}`,
          numQuestions: 0
        }),
      });
      
      // Transform the response into notes format if needed
      const notesContent = Array.isArray(result.questions) 
        ? `# ${title}\n\n${result.questions.join('\n\n')}` 
        : typeof result.questions === 'string' 
          ? `# ${title}\n\n${result.questions}` 
          : `# ${title}\n\nNo notes could be generated.`;
      
      setNotes(notesContent);
      setLoading(false);
      
      toast({
        title: "Notes generated",
        description: "Your AI study notes have been generated successfully."
      });
    } catch (err) {
      console.error('Error generating notes:', err);
      setError('Failed to generate notes. Please try again later.');
      setLoading(false);
      
      toast({
        title: "Error",
        description: "Failed to generate notes. Please make sure your Google AI API key is configured.",
        variant: "destructive"
      });
    }
  };

  const generateNotesFromYoutube = async () => {
    if (!validateYoutubeUrl()) {
      return;
    }

    // Make sure we have a valid videoId
    if (!videoId) {
      setError('Could not extract a valid YouTube video ID from the URL');
      toast({
        title: "Invalid URL",
        description: "Could not extract a valid YouTube video ID from the URL.",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      console.log("Generating notes for video ID:", videoId);
      const result = await apiRequest<{ notes: string }>(`/api/videos/${videoId}/generate-notes`);
      
      if (!result || !result.notes) {
        throw new Error("No notes were returned from the API");
      }
      
      // Check if we need to add a title
      const hasTitle = result.notes.startsWith('# ') || result.notes.startsWith('#');
      const finalNotes = hasTitle ? result.notes : `# Notes for YouTube Video\n\n${result.notes}`;
      
      setNotes(finalNotes);
      setLoading(false);
      
      toast({
        title: "Notes generated",
        description: "Your AI study notes have been generated successfully from the YouTube video."
      });
    } catch (err) {
      console.error('Error generating notes from YouTube:', err);
      setError('Failed to generate notes from YouTube. Please try again later.');
      setLoading(false);
      
      toast({
        title: "Error",
        description: "Failed to generate notes from YouTube. Please check the URL and ensure your Google AI API key is configured.",
        variant: "destructive"
      });
    }
  };

  const handleGenerateNotes = () => {
    if (activeTab === 'text') {
      generateNotesFromText();
    } else if (activeTab === 'youtube') {
      generateNotesFromYoutube();
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <h1 className="text-3xl font-bold mb-6 bg-gradient-to-r from-primary to-indigo-500 text-transparent bg-clip-text">
          AI Notes Generator
        </h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <Card className="lg:col-span-7 overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Generate Study Notes
              </CardTitle>
              <CardDescription>
                Generate comprehensive AI-powered study notes from text, YouTube videos, or articles
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-4 w-full grid grid-cols-2">
                  <TabsTrigger value="text" className="flex items-center">
                    <BookOpen className="h-4 w-4 mr-2" />
                    <span>From Text</span>
                  </TabsTrigger>
                  <TabsTrigger value="youtube" className="flex items-center">
                    <Youtube className="h-4 w-4 mr-2" />
                    <span>From YouTube</span>
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="text" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Topic Title</Label>
                    <Input
                      id="title"
                      placeholder="Enter a title for your notes"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="content">Content</Label>
                    <Textarea
                      id="content"
                      placeholder="Paste text content or write something to generate notes from"
                      value={content}
                      onChange={(e) => setContent(e.target.value)}
                      className="min-h-[200px]"
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="youtube" className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="youtube-url">YouTube Video URL</Label>
                    <div className="flex gap-2">
                      <Input
                        id="youtube-url"
                        placeholder="https://www.youtube.com/watch?v=VIDEO_ID"
                        value={youtubeUrl}
                        onChange={(e) => setYoutubeUrl(e.target.value)}
                        className="flex-1"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Enter a YouTube video URL to generate notes from its transcript
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
              
              {error && (
                <Alert variant="destructive" className="mt-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
            
            <CardFooter className="border-t p-4 bg-muted/50">
              <Button 
                onClick={handleGenerateNotes}
                disabled={loading || (activeTab === 'text' && (!title || !content)) || (activeTab === 'youtube' && !youtubeUrl)}
                className="ml-auto"
              >
                {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <FileText className="h-4 w-4 mr-2" />}
                {notes ? "Regenerate Notes" : "Generate Notes"}
              </Button>
            </CardFooter>
          </Card>
          
          <Card className="lg:col-span-5">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BookOpen className="h-5 w-5 mr-2" />
                Your AI Notes
              </CardTitle>
            </CardHeader>
            
            <CardContent>
              {loading ? (
                <div className="space-y-2">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-5/6" />
                  <Skeleton className="h-6 w-2/4 mt-4" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                </div>
              ) : notes ? (
                <div className="max-h-[500px] overflow-y-auto pr-2">
                  <Markdown content={notes} />
                </div>
              ) : (
                <div className="text-center py-20 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Enter your details and click "Generate Notes" to create AI-powered study notes.</p>
                  <p className="text-sm mt-2">Notes will include key concepts, definitions, and summaries.</p>
                </div>
              )}
            </CardContent>
            
            {notes && (
              <CardFooter className="border-t p-4 flex justify-between">
                <Button variant="outline" size="sm" onClick={() => {
                  navigator.clipboard.writeText(notes);
                  toast({ title: "Copied", description: "Notes copied to clipboard" });
                }}>
                  <LinkIcon className="h-4 w-4 mr-2" />
                  Copy to Clipboard
                </Button>
                
                <Button variant="secondary" size="sm" onClick={() => setNotes(null)}>
                  Clear Notes
                </Button>
              </CardFooter>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}