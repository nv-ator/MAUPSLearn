import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Course } from "@/lib/types";
import { Search, BookOpen, Star, Clock } from "lucide-react";
import { useState } from "react";

export default function Courses() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string | null>(null);
  
  const { data: courses, isLoading } = useQuery<Course[]>({ 
    queryKey: ['/api/courses'] 
  });
  
  const filteredCourses = courses?.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          course.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesDifficulty = !selectedDifficulty || course.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesDifficulty;
  });
  
  const difficultyLevels = ["Beginner", "Intermediate", "Advanced"];
  
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Courses</h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Browse our FinTech learning courses</p>
          </div>
        </div>
        
        {/* Search and Filters */}
        <div className="mt-6 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search courses..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <div className="flex flex-wrap gap-2">
            {difficultyLevels.map(difficulty => (
              <Badge
                key={difficulty}
                variant={selectedDifficulty === difficulty ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setSelectedDifficulty(selectedDifficulty === difficulty ? null : difficulty)}
              >
                {difficulty}
              </Badge>
            ))}
          </div>
        </div>
        
        {/* Course Grid */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 6 }).map((_, index) => (
              <Card key={index} className="overflow-hidden">
                <Skeleton className="h-48 w-full" />
                <CardContent className="pt-6">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-2/3" />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Skeleton className="h-8 w-1/3" />
                  <Skeleton className="h-8 w-1/3" />
                </CardFooter>
              </Card>
            ))
          ) : filteredCourses && filteredCourses.length > 0 ? (
            filteredCourses.map(course => (
              <Card key={course.id} className="overflow-hidden flex flex-col">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={course.thumbnail} 
                    alt={course.title} 
                    className="w-full h-full object-cover transition-transform hover:scale-105"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge variant="secondary">
                      {course.difficulty}
                    </Badge>
                  </div>
                </div>
                
                <CardContent className="pt-6 flex-grow">
                  <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                    {course.title}
                  </h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 line-clamp-2">
                    {course.description}
                  </p>
                  
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 space-x-3">
                    <div className="flex items-center">
                      <BookOpen className="h-3.5 w-3.5 mr-1" />
                      <span>{course.totalVideos} videos</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="h-3.5 w-3.5 mr-1 text-amber-500" />
                      <span>4.8 (126)</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      <span>2h 45m</span>
                    </div>
                  </div>
                </CardContent>
                
                <CardFooter className="border-t pt-4">
                  <Link href={`/courses/${course.id}`}>
                    <a className="w-full">
                      <Button variant="default" className="w-full">
                        Start Learning
                      </Button>
                    </a>
                  </Link>
                </CardFooter>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 dark:text-gray-400 mb-4">
                No courses found matching your search criteria
              </p>
              <Button onClick={() => {
                setSearchQuery("");
                setSelectedDifficulty(null);
              }}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
