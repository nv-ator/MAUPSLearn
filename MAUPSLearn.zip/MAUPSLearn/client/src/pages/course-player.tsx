import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Course, Video, Progress as ProgressType, Quiz } from "@/lib/types";
import { YouTubePlayer } from "@/components/ui/youtube-player";
import { YoutubePlaylistWrapper } from "@/components/ui/youtube-playlist-wrapper";
import { Quiz as QuizComponent } from "@/components/ui/quiz";
import { 
  ChevronLeft, 
  Play, 
  List, 
  HelpCircle, 
  MessageSquare, 
  CheckCircle, 
  Clock, 
  ArrowRight, 
  FileText 
} from "lucide-react";

export default function CoursePlayer() {
  const { courseId } = useParams();
  const [selectedVideoId, setSelectedVideoId] = useState<number | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);

  // Fetch course details
  const { data: course, isLoading: courseLoading } = useQuery<Course>({
    queryKey: [`/api/courses/${courseId}`]
  });

  // Fetch videos for this course
  const { data: videos, isLoading: videosLoading } = useQuery<Video[]>({
    queryKey: [`/api/courses/${courseId}/videos`],
    enabled: !!courseId
  });

  // Fetch progress for the current user for this course
  const { data: progress, isLoading: progressLoading } = useQuery<ProgressType[]>({
    queryKey: [`/api/users/1/courses/${courseId}/progress`],
    enabled: !!courseId
  });

  // Fetch quiz for the selected video
  const { data: quiz, isLoading: quizLoading } = useQuery<Quiz>({
    queryKey: [`/api/videos/${selectedVideoId}/quiz`],
    enabled: !!selectedVideoId && showQuiz
  });

  // Set the first video as selected when videos are loaded
  useEffect(() => {
    if (videos && videos.length > 0 && !selectedVideoId) {
      setSelectedVideoId(videos[0].id);
    }
  }, [videos, selectedVideoId]);

  // Get the currently selected video
  const currentVideo = videos?.find(video => video.id === selectedVideoId);

  // Calculate course completion percentage
  const calculateCompletion = () => {
    if (!videos || !progress) return 0;
    
    const completedVideos = progress.filter(p => p.completed).length;
    return Math.round((completedVideos / videos.length) * 100);
  };

  // Handle video progress updates
  const handleVideoProgress = async (progressPercent: number) => {
    setVideoProgress(progressPercent);
    
    // Save progress to API every 5 seconds or when it reaches certain thresholds
    // In a real app, you'd want a more sophisticated approach to avoid too many API calls
    if (currentVideo && (progressPercent >= 90 || progressPercent % 5 === 0)) {
      try {
        await apiRequest(`/api/progress`, {
          method: 'POST',
          body: JSON.stringify({
            userId: 1, // In a real app, get from auth context
            courseId: parseInt(courseId || '0'),
            videoId: currentVideo.id,
            completed: progressPercent >= 90,
            watchTime: Math.floor((progressPercent / 100) * currentVideo.duration)
          })
        });
      } catch (error) {
        console.error("Error saving progress:", error);
      }
    }
  };

  // Handle video end event
  const handleVideoEnd = async () => {
    if (currentVideo) {
      try {
        await apiRequest(`/api/progress`, {
          method: 'POST',
          body: JSON.stringify({
            userId: 1, // In a real app, get from auth context
            courseId: parseInt(courseId || '0'),
            videoId: currentVideo.id,
            completed: true,
            watchTime: currentVideo.duration
          })
        });
        
        // Show quiz after video completes
        setShowQuiz(true);
      } catch (error) {
        console.error("Error saving completion:", error);
      }
    }
  };

  // Handle quiz completion
  const handleQuizComplete = async (score: number, answers: number[]) => {
    if (quiz && selectedVideoId) {
      try {
        await apiRequest(`/api/quizzes/${quiz.id}/submit`, {
          method: 'POST',
          body: JSON.stringify({
            userId: 1, // In a real app, get from auth context
            answers
          })
        });
        
        // Hide quiz after completion
        setShowQuiz(false);
        
        // Auto-advance to next video if available
        if (videos && currentVideo) {
          const currentIndex = videos.findIndex(video => video.id === currentVideo.id);
          if (currentIndex < videos.length - 1) {
            setSelectedVideoId(videos[currentIndex + 1].id);
          }
        }
      } catch (error) {
        console.error("Error submitting quiz:", error);
      }
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header with back button */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex items-center">
          <Link href="/courses">
            <a className="inline-flex items-center mr-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
              <ChevronLeft className="h-5 w-5 mr-1" />
              Back to Courses
            </a>
          </Link>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
            {courseLoading ? (
              <Skeleton className="h-8 w-64" />
            ) : course ? (
              course.title
            ) : (
              "Course not found"
            )}
          </h1>
        </div>

        <div className="mt-6 flex flex-col lg:flex-row gap-6">
          {/* Main content area */}
          <div className="lg:w-2/3">
            {/* Video Player */}
            {videosLoading || !currentVideo ? (
              <Skeleton className="w-full aspect-video rounded-lg mb-4" />
            ) : showQuiz ? (
              quizLoading ? (
                <Skeleton className="w-full h-[500px] rounded-lg mb-4" />
              ) : quiz ? (
                <QuizComponent
                  questions={quiz.questions}
                  onComplete={handleQuizComplete}
                />
              ) : (
                <Card className="mb-4">
                  <CardContent className="pt-6 text-center">
                    <HelpCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                      Quiz not available
                    </h3>
                    <p className="text-gray-500 dark:text-gray-400 mt-2">
                      We couldn't load the quiz for this video. Please try again later.
                    </p>
                    <Button
                      onClick={() => setShowQuiz(false)}
                      className="mt-4"
                    >
                      Continue Watching
                    </Button>
                  </CardContent>
                </Card>
              )
            ) : (
              <div className="mb-4">
                <YouTubePlayer
                  videoId={currentVideo.videoId}
                  title={currentVideo.title}
                  onProgress={handleVideoProgress}
                  onVideoEnd={handleVideoEnd}
                />
              </div>
            )}

            {/* Video Info */}
            {currentVideo && !showQuiz && (
              <Card className="mb-6">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{currentVideo.title}</CardTitle>
                      <CardDescription>
                        Module {currentVideo.position} • {Math.floor(currentVideo.duration / 60)}:{(currentVideo.duration % 60).toString().padStart(2, '0')} minutes
                      </CardDescription>
                    </div>
                    {!showQuiz && (
                      <Button onClick={() => setShowQuiz(true)}>
                        <HelpCircle className="mr-2 h-4 w-4" />
                        Take Quiz
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="description">
                    <TabsList>
                      <TabsTrigger value="description">Description</TabsTrigger>
                      <TabsTrigger value="notes">Notes</TabsTrigger>
                      <TabsTrigger value="discussions">Discussions</TabsTrigger>
                    </TabsList>
                    <TabsContent value="description" className="mt-4">
                      <p className="text-gray-700 dark:text-gray-300">
                        {currentVideo.description || 
                          "Learn about the key concepts and applications of this topic in finance technology. This video covers fundamental principles and practical examples to help you understand the subject matter thoroughly."}
                      </p>
                      
                      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <h3 className="font-medium text-gray-900 dark:text-white mb-2">What you'll learn</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                            <span>Understand the fundamental concepts of {currentVideo.title.split(' ').slice(-1)}</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                            <span>Apply theoretical knowledge to real-world financial scenarios</span>
                          </li>
                          <li className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 mr-2 flex-shrink-0" />
                            <span>Analyze the impact of this technology on traditional finance</span>
                          </li>
                        </ul>
                      </div>
                    </TabsContent>
                    <TabsContent value="notes" className="mt-4">
                      <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg text-center">
                        <FileText className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                        <p className="text-gray-500 dark:text-gray-400">
                          You haven't taken any notes for this video yet.
                        </p>
                        <Button variant="outline" className="mt-3">
                          Add Notes
                        </Button>
                      </div>
                    </TabsContent>
                    <TabsContent value="discussions" className="mt-4">
                      <div className="space-y-4">
                        <div className="flex space-x-3">
                          <div className="flex-shrink-0">
                            <img
                              className="h-10 w-10 rounded-full"
                              src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                              alt="User profile"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              Emily Chen
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              The explanation about smart contracts at 8:45 was really helpful. Does anyone have additional resources on this topic?
                            </p>
                            <div className="mt-2 flex items-center space-x-2 text-sm">
                              <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                                <MessageSquare className="h-4 w-4 inline mr-1" /> Reply
                              </button>
                              <span className="text-gray-300 dark:text-gray-600">|</span>
                              <span className="text-gray-500 dark:text-gray-400">2 days ago</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex space-x-3">
                          <div className="flex-shrink-0">
                            <img
                              className="h-10 w-10 rounded-full"
                              src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                              alt="User profile"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              Michael Scott
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              I think the comparison between traditional finance and DeFi could be expanded a bit more. Looking forward to the next video in this series.
                            </p>
                            <div className="mt-2 flex items-center space-x-2 text-sm">
                              <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                                <MessageSquare className="h-4 w-4 inline mr-1" /> Reply
                              </button>
                              <span className="text-gray-300 dark:text-gray-600">|</span>
                              <span className="text-gray-500 dark:text-gray-400">1 week ago</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <Button variant="outline" className="w-full">
                          <MessageSquare className="mr-2 h-4 w-4" />
                          Add Comment
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:w-1/3">
            {/* Course Progress Card */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-base">Course Progress</CardTitle>
              </CardHeader>
              <CardContent>
                {progressLoading || videosLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-20 w-full" />
                  </div>
                ) : videos ? (
                  <>
                    <div className="mb-2 flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {progress?.filter(p => p.completed).length || 0} of {videos.length} completed
                      </span>
                      <span className="text-sm font-medium text-primary-600 dark:text-primary-400">
                        {calculateCompletion()}%
                      </span>
                    </div>
                    
                    <Progress value={calculateCompletion()} className="mb-4" />
                    
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 flex items-center">
                      <Clock className="h-5 w-5 text-gray-400 mr-3" />
                      <div className="text-sm">
                        <p className="font-medium text-gray-900 dark:text-white">
                          Estimated time to complete
                        </p>
                        <p className="text-gray-500 dark:text-gray-400">
                          {Math.round(videos.reduce((acc, video) => acc + video.duration, 0) / 60)} minutes remaining
                        </p>
                      </div>
                    </div>
                  </>
                ) : (
                  <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                    Failed to load progress
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Course Content Card */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center">
                  <List className="mr-2 h-4 w-4" />
                  Course Content
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="divide-y divide-gray-200 dark:divide-gray-700">
                  {videosLoading ? (
                    Array.from({ length: 5 }).map((_, index) => (
                      <div key={index} className="p-4">
                        <Skeleton className="h-5 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    ))
                  ) : videos && videos.length > 0 ? (
                    videos.map((video) => {
                      const isActive = video.id === selectedVideoId;
                      const isCompleted = progress?.some(p => p.videoId === video.id && p.completed);
                      
                      return (
                        <button
                          key={video.id}
                          onClick={() => {
                            setSelectedVideoId(video.id);
                            setShowQuiz(false);
                          }}
                          className={`w-full text-left p-4 transition-colors hover:bg-gray-50 dark:hover:bg-gray-800 ${
                            isActive ? 'bg-primary-50 dark:bg-primary-900/20' : ''
                          }`}
                        >
                          <div className="flex items-start">
                            <div className="mr-3 mt-0.5">
                              {isCompleted ? (
                                <div className="h-6 w-6 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                                  <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                                </div>
                              ) : isActive ? (
                                <div className="h-6 w-6 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                                  <Play className="h-4 w-4 text-primary-600 dark:text-primary-400" />
                                </div>
                              ) : (
                                <div className="h-6 w-6 rounded-full border border-gray-300 dark:border-gray-600 flex items-center justify-center text-xs text-gray-500 dark:text-gray-400">
                                  {video.position}
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className={`font-medium text-sm truncate ${
                                isActive 
                                  ? 'text-primary-700 dark:text-primary-300' 
                                  : 'text-gray-900 dark:text-white'
                              }`}>
                                {video.title}
                              </h4>
                              <div className="flex items-center mt-1">
                                <Clock className="h-3.5 w-3.5 text-gray-400 mr-1" />
                                <span className="text-xs text-gray-500 dark:text-gray-400">
                                  {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')}
                                </span>
                                
                                {progress?.some(p => p.videoId === video.id && !p.completed && p.watchTime > 0) && (
                                  <Badge variant="outline" className="ml-2 text-xs">
                                    In Progress
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </button>
                      );
                    })
                  ) : (
                    <div className="p-4 text-center">
                      <p className="text-gray-500 dark:text-gray-400">
                        No videos available
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="border-t border-gray-200 dark:border-gray-700">
                <div className="w-full">
                  {currentVideo && videos && (
                    <div className="flex justify-between items-center w-full">
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentVideo.position <= 1}
                        onClick={() => {
                          const prevVideo = videos.find(v => v.position === currentVideo.position - 1);
                          if (prevVideo) {
                            setSelectedVideoId(prevVideo.id);
                            setShowQuiz(false);
                          }
                        }}
                      >
                        <ChevronLeft className="h-5 w-5 mr-1" />
                        Previous
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={currentVideo.position >= videos.length}
                        onClick={() => {
                          const nextVideo = videos.find(v => v.position === currentVideo.position + 1);
                          if (nextVideo) {
                            setSelectedVideoId(nextVideo.id);
                            setShowQuiz(false);
                          }
                        }}
                      >
                        Next
                        <ArrowRight className="h-5 w-5 ml-1" />
                      </Button>
                    </div>
                  )}
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
