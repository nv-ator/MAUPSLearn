import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { User, Challenge } from "@/lib/types";
import { 
  Users,
  Trophy,
  Search,
  Calendar,
  MessageSquare,
  UserPlus,
  Heart,
  Award,
  BarChart2,
  Crown,
  Target
} from "lucide-react";

export default function Community() {
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch leaderboard
  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery<User[]>({
    queryKey: ['/api/leaderboard']
  });

  // Fetch challenges
  const { data: challenges, isLoading: challengesLoading } = useQuery<Challenge[]>({
    queryKey: ['/api/challenges']
  });

  // Filter users based on search query
  const filteredUsers = leaderboard?.filter(user => 
    user.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Community</h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Connect with other learners and join challenges</p>
          </div>
        </div>

        <Tabs defaultValue="leaderboard" className="mt-6">
          <TabsList className="mb-6">
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            <TabsTrigger value="challenges">Challenges</TabsTrigger>
            <TabsTrigger value="discussions">Discussions</TabsTrigger>
          </TabsList>

          {/* Leaderboard Tab */}
          <TabsContent value="leaderboard">
            <div className="flex flex-col lg:flex-row gap-6">
              <div className="lg:w-2/3">
                <Card className="mb-6">
                  <CardHeader className="pb-2">
                    <CardTitle className="flex items-center">
                      <Trophy className="mr-2 h-5 w-5 text-amber-500" />
                      Top Learners
                    </CardTitle>
                    <CardDescription>
                      Compete with others to climb the ranks
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex mb-6">
                      <div className="relative flex-1">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                        <Input 
                          placeholder="Search users..."
                          className="pl-9"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                        />
                      </div>
                    </div>

                    {leaderboardLoading ? (
                      <div className="space-y-4">
                        {Array.from({ length: 5 }).map((_, index) => (
                          <div key={index} className="flex items-center p-2">
                            <Skeleton className="h-8 w-8 rounded-full" />
                            <div className="ml-3 flex-1">
                              <Skeleton className="h-4 w-24" />
                              <Skeleton className="h-3 w-16 mt-1" />
                            </div>
                            <Skeleton className="h-4 w-16" />
                          </div>
                        ))}
                      </div>
                    ) : filteredUsers && filteredUsers.length > 0 ? (
                      <div className="space-y-2">
                        {filteredUsers.map((user, index) => {
                          const isCurrentUser = user.id === 1; // In a real app, compare with authenticated user
                          
                          // Determine badge for top 3
                          let badge = null;
                          if (index === 0) {
                            badge = <Crown className="h-5 w-5 text-amber-500" />;
                          } else if (index === 1) {
                            badge = <Crown className="h-5 w-5 text-gray-400" />;
                          } else if (index === 2) {
                            badge = <Crown className="h-5 w-5 text-amber-700" />;
                          }
                          
                          return (
                            <div 
                              key={user.id} 
                              className={`flex items-center p-3 rounded-lg ${
                                isCurrentUser 
                                  ? 'bg-primary-50 dark:bg-primary-900/20 border border-primary-200 dark:border-primary-800' 
                                  : 'hover:bg-gray-50 dark:hover:bg-gray-800 border border-transparent'
                              }`}
                            >
                              <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-500 font-semibold text-sm">
                                {index + 1}
                              </div>
                              
                              <div className="ml-3 flex-1 flex items-center">
                                <Avatar className="h-10 w-10">
                                  <AvatarImage src={user.avatar} alt={user.displayName} />
                                  <AvatarFallback>{user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                                </Avatar>
                                
                                <div className="ml-3">
                                  <div className="flex items-center">
                                    <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                                      {user.displayName}
                                    </h3>
                                    {isCurrentUser && (
                                      <Badge variant="outline" className="ml-2 text-xs">You</Badge>
                                    )}
                                    {badge && (
                                      <span className="ml-2">{badge}</span>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-500 dark:text-gray-400">
                                    Level {user.level} • {user.streak} day streak
                                  </p>
                                </div>
                              </div>
                              
                              <div className="text-right">
                                <p className="text-sm font-medium text-gray-900 dark:text-white">
                                  {user.points} pts
                                </p>
                                {!isCurrentUser && (
                                  <Button variant="ghost" size="sm" className="p-0 h-auto mt-1">
                                    <UserPlus className="h-3.5 w-3.5 mr-1" />
                                    <span className="text-xs">Follow</span>
                                  </Button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Users className="mx-auto h-12 w-12 text-gray-400 mb-3" />
                        <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                          No users found
                        </h3>
                        <p className="text-gray-500 dark:text-gray-400 mt-2">
                          Try a different search term
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="lg:w-1/3 space-y-6">
                {/* Your Ranking Card */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base">Your Ranking</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {leaderboardLoading ? (
                      <div className="space-y-4">
                        <Skeleton className="h-20 w-full" />
                        <Skeleton className="h-4 w-full" />
                      </div>
                    ) : leaderboard ? (
                      <div>
                        <div className="bg-primary-50 dark:bg-primary-900/20 rounded-lg p-4 mb-4">
                          <div className="flex items-center">
                            <Avatar className="h-12 w-12">
                              <AvatarImage 
                                src={leaderboard.find(u => u.id === 1)?.avatar} 
                                alt="Your profile" 
                              />
                              <AvatarFallback>YU</AvatarFallback>
                            </Avatar>
                            <div className="ml-4">
                              <h3 className="font-medium text-gray-900 dark:text-white">
                                {leaderboard.find(u => u.id === 1)?.displayName}
                              </h3>
                              <p className="text-sm text-gray-500 dark:text-gray-400">
                                Rank #{leaderboard.findIndex(u => u.id === 1) + 1}
                              </p>
                            </div>
                            <div className="ml-auto text-right">
                              <span className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                                {leaderboard.find(u => u.id === 1)?.points}
                              </span>
                              <p className="text-xs text-gray-500 dark:text-gray-400">points</p>
                            </div>
                          </div>
                        </div>
                        
                        {leaderboard.findIndex(u => u.id === 1) > 0 && (
                          <>
                            <div className="mb-2 flex justify-between">
                              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Next Rank Progress
                              </h4>
                              <span className="text-sm text-primary-600 dark:text-primary-400 font-medium">
                                {Math.min(100, Math.round((leaderboard.find(u => u.id === 1)?.points || 0) / (leaderboard[leaderboard.findIndex(u => u.id === 1) - 1]?.points || 1) * 100))}%
                              </span>
                            </div>
                            
                            <Progress 
                              value={Math.min(100, Math.round((leaderboard.find(u => u.id === 1)?.points || 0) / (leaderboard[leaderboard.findIndex(u => u.id === 1) - 1]?.points || 1) * 100))} 
                              className="mb-4" 
                            />
                            
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              Need {(leaderboard[leaderboard.findIndex(u => u.id === 1) - 1]?.points || 0) - (leaderboard.find(u => u.id === 1)?.points || 0)} more points to overtake {leaderboard[leaderboard.findIndex(u => u.id === 1) - 1]?.displayName}
                            </p>
                          </>
                        )}
                      </div>
                    ) : (
                      <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                        Failed to load ranking
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Achievement Stats Card */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base flex items-center">
                      <Award className="mr-2 h-4 w-4 text-amber-500" />
                      Achievement Stats
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                        <Trophy className="h-6 w-6 mx-auto text-amber-500 mb-1" />
                        <p className="text-2xl font-semibold">3</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Achievements Unlocked
                        </p>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                        <BarChart2 className="h-6 w-6 mx-auto text-primary-500 mb-1" />
                        <p className="text-2xl font-semibold">12</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Quizzes Completed
                        </p>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                        <Target className="h-6 w-6 mx-auto text-emerald-500 mb-1" />
                        <p className="text-2xl font-semibold">2</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Challenges Joined
                        </p>
                      </div>
                      
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3 text-center">
                        <Calendar className="h-6 w-6 mx-auto text-violet-500 mb-1" />
                        <p className="text-2xl font-semibold">7</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          Day Streak
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Challenges Tab */}
          <TabsContent value="challenges">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {challengesLoading ? (
                Array.from({ length: 6 }).map((_, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <Skeleton className="h-5 w-3/4 mb-2" />
                      <Skeleton className="h-4 w-full" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-32 w-full rounded-md" />
                    </CardContent>
                    <CardFooter>
                      <Skeleton className="h-10 w-full" />
                    </CardFooter>
                  </Card>
                ))
              ) : challenges && challenges.length > 0 ? (
                challenges.map(challenge => (
                  <Card key={challenge.id}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-base">{challenge.title}</CardTitle>
                        <Badge>
                          {challenge.isTeamChallenge ? 'Team' : 'Individual'}
                        </Badge>
                      </div>
                      <CardDescription>
                        {new Date(challenge.endDate) > new Date() 
                          ? `${Math.ceil((new Date(challenge.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left` 
                          : 'Ended'}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mb-4">
                        <p className="text-sm mb-4">{challenge.description}</p>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-gray-400" />
                            <span className="text-gray-500 dark:text-gray-400">
                              {new Date(challenge.startDate).toLocaleDateString()} - {new Date(challenge.endDate).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Trophy className="h-4 w-4 mr-1 text-amber-500" />
                            <span className="text-amber-600 dark:text-amber-400 font-medium">
                              {challenge.pointsReward} pts
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-1 mb-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                          <AvatarFallback>AR</AvatarFallback>
                        </Avatar>
                        <Avatar className="h-6 w-6">
                          <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                          <AvatarFallback>EC</AvatarFallback>
                        </Avatar>
                        <Avatar className="h-6 w-6">
                          <AvatarImage src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                          <AvatarFallback>MS</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">
                          +15 participants
                        </span>
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button className="w-full">
                        Join Challenge
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <Trophy className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white">No active challenges</h3>
                  <p className="text-gray-500 dark:text-gray-400 mt-2">
                    Check back later for new challenges
                  </p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Discussions Tab */}
          <TabsContent value="discussions">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="mr-2 h-5 w-5 text-primary-500" />
                  Community Discussions
                </CardTitle>
                <CardDescription>
                  Connect with other learners and share your knowledge
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Sample discussions - in a real app, these would come from an API */}
                  <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                        <AvatarFallback>EC</AvatarFallback>
                      </Avatar>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-medium text-gray-900 dark:text-white">Emily Chen</span>
                            <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">2 hours ago</span>
                          </div>
                          <Badge variant="outline">DeFi</Badge>
                        </div>
                        <h3 className="font-medium mt-1">Thoughts on the DeFi market in 2024?</h3>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                          I've been watching the DeFi space closely this year and noticed some interesting trends. What are your thoughts on the recent developments?
                        </p>
                        <div className="flex items-center mt-3 text-sm text-gray-500 dark:text-gray-400">
                          <button className="flex items-center mr-4">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            12 replies
                          </button>
                          <button className="flex items-center">
                            <Heart className="h-4 w-4 mr-1" />
                            24 likes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src="https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                        <AvatarFallback>DK</AvatarFallback>
                      </Avatar>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-medium text-gray-900 dark:text-white">David Kim</span>
                            <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">Yesterday</span>
                          </div>
                          <Badge variant="outline">Banking</Badge>
                        </div>
                        <h3 className="font-medium mt-1">Resources for learning about banking APIs?</h3>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                          I'm working on a project that requires integrating with banking APIs. Does anyone have recommendations for good learning resources?
                        </p>
                        <div className="flex items-center mt-3 text-sm text-gray-500 dark:text-gray-400">
                          <button className="flex items-center mr-4">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            8 replies
                          </button>
                          <button className="flex items-center">
                            <Heart className="h-4 w-4 mr-1" />
                            15 likes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                    <div className="flex">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src="https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" />
                        <AvatarFallback>MS</AvatarFallback>
                      </Avatar>
                      <div className="ml-3 flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-medium text-gray-900 dark:text-white">Michael Scott</span>
                            <span className="text-gray-500 dark:text-gray-400 text-sm ml-2">3 days ago</span>
                          </div>
                          <Badge variant="outline">Crypto</Badge>
                        </div>
                        <h3 className="font-medium mt-1">How to explain cryptocurrency to beginners?</h3>
                        <p className="text-gray-600 dark:text-gray-300 text-sm mt-1">
                          I'm trying to explain cryptocurrency concepts to friends who have no technical background. What analogies or explanations have worked for you?
                        </p>
                        <div className="flex items-center mt-3 text-sm text-gray-500 dark:text-gray-400">
                          <button className="flex items-center mr-4">
                            <MessageSquare className="h-4 w-4 mr-1" />
                            21 replies
                          </button>
                          <button className="flex items-center">
                            <Heart className="h-4 w-4 mr-1" />
                            32 likes
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-center">
                <Button variant="outline">
                  Start a New Discussion
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
