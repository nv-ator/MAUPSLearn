import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { User, Challenge, ChallengeParticipant } from "@/lib/types";
import { 
  Trophy, 
  Medal, 
  Target, 
  Calendar, 
  Users, 
  BookOpen, 
  BarChart,
  Award,
  ChevronUp,
  Flame
} from "lucide-react";

export default function Achievements() {
  // Fetch user data
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ['/api/users/1']
  });

  // Fetch challenges data
  const { data: userChallenges, isLoading: challengesLoading } = useQuery<{
    challenge: Challenge;
    participant: ChallengeParticipant;
  }[]>({
    queryKey: ['/api/users/1/challenges']
  });

  // Mock achievements data (in a real app, this would come from the API)
  const achievements = [
    {
      id: 1,
      title: "Fast Learner",
      description: "Complete your first course",
      icon: BookOpen,
      progress: 75,
      unlocked: false,
      category: "learning"
    },
    {
      id: 2,
      title: "Quiz Master",
      description: "Score 100% on 5 quizzes",
      icon: Award,
      progress: 60,
      unlocked: false,
      category: "quiz"
    },
    {
      id: 3,
      title: "Social Butterfly",
      description: "Join your first team challenge",
      icon: Users,
      progress: 100,
      unlocked: true,
      date: "May 15, 2024",
      category: "social"
    },
    {
      id: 4,
      title: "Streak Keeper",
      description: "Maintain a 7-day learning streak",
      icon: Flame,
      progress: 100,
      unlocked: true,
      date: "May 10, 2024",
      category: "streak"
    },
    {
      id: 5,
      title: "Chart Topper",
      description: "Reach the top 3 on the leaderboard",
      icon: BarChart,
      progress: 0,
      unlocked: false,
      category: "social"
    },
    {
      id: 6,
      title: "First Steps",
      description: "Watch your first video",
      icon: BookOpen,
      progress: 100,
      unlocked: true,
      date: "May 8, 2024",
      category: "learning"
    }
  ];

  // Level progression calculation
  const currentLevel = user?.level || 1;
  const pointsForNextLevel = currentLevel * 500;
  const currentLevelMinPoints = (currentLevel - 1) * 500;
  const nextLevelProgress = user 
    ? Math.min(100, Math.round(((user.points - currentLevelMinPoints) / (pointsForNextLevel - currentLevelMinPoints)) * 100))
    : 0;

  // Get streak data
  const streak = user?.streak || 0;

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Achievements</h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Track your progress and unlock rewards</p>
          </div>
        </div>

        {/* User Stats Section */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Level Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg">
                <Medal className="mr-2 h-5 w-5 text-primary-500" />
                Level Progress
              </CardTitle>
              <CardDescription>
                Keep learning to level up
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-32 w-32 rounded-full mx-auto" />
                  <Skeleton className="h-4 w-3/4 mx-auto" />
                  <Skeleton className="h-2 w-full" />
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div className="relative mb-6">
                    <div className="w-32 h-32 rounded-full border-8 border-primary-100 dark:border-primary-900 flex items-center justify-center">
                      <span className="text-4xl font-bold text-primary-600 dark:text-primary-400">{currentLevel}</span>
                    </div>
                    <div className="absolute -bottom-2 right-0 bg-primary-500 text-white text-xs font-bold rounded-full h-8 w-8 flex items-center justify-center">
                      <ChevronUp className="h-5 w-5" />
                    </div>
                  </div>
                  
                  <div className="w-full mb-2 flex justify-between items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {user?.points || 0} points
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {pointsForNextLevel} points
                    </span>
                  </div>
                  
                  <Progress value={nextLevelProgress} className="w-full" />
                  
                  <p className="mt-4 text-sm text-center text-gray-600 dark:text-gray-300">
                    {pointsForNextLevel - (user?.points || 0)} more points needed for level {currentLevel + 1}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Streak Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg">
                <Flame className="mr-2 h-5 w-5 text-amber-500" />
                Learning Streak
              </CardTitle>
              <CardDescription>
                Learn every day to maintain your streak
              </CardDescription>
            </CardHeader>
            <CardContent>
              {userLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-4 w-3/4 mx-auto" />
                </div>
              ) : (
                <div className="flex flex-col items-center">
                  <div className="grid grid-cols-7 gap-2 w-full mb-6">
                    {Array.from({ length: 7 }).map((_, i) => (
                      <div 
                        key={i} 
                        className={`aspect-square rounded-md flex items-center justify-center ${
                          i < streak % 7 
                            ? 'bg-amber-500 text-white' 
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-400 dark:text-gray-500'
                        }`}
                      >
                        {i < streak % 7 ? (
                          <Flame className="h-6 w-6" />
                        ) : (
                          <span className="text-lg">{i + 1}</span>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-center bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300 px-4 py-3 rounded-lg w-full">
                    <Flame className="h-8 w-8 mr-3" />
                    <div>
                      <p className="font-semibold">
                        {streak} Day Streak!
                      </p>
                      <p className="text-sm">
                        {streak >= 7 
                          ? "Great job maintaining your streak!" 
                          : `${7 - streak} more days until your next streak achievement`}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Challenges Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg">
                <Target className="mr-2 h-5 w-5 text-emerald-500" />
                Active Challenges
              </CardTitle>
              <CardDescription>
                Your ongoing challenge progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              {challengesLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-24 w-full" />
                </div>
              ) : userChallenges && userChallenges.length > 0 ? (
                <div className="space-y-4">
                  {userChallenges.map(({ challenge, participant }) => (
                    <div key={challenge.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-3">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center">
                          <span className={`flex-shrink-0 h-8 w-8 rounded-full ${
                            challenge.isTeamChallenge 
                              ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400' 
                              : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400'
                          } flex items-center justify-center`}
                          >
                            {challenge.isTeamChallenge ? (
                              <Users className="h-4 w-4" />
                            ) : (
                              <Calendar className="h-4 w-4" />
                            )}
                          </span>
                          <span className="ml-2 font-medium text-sm">
                            {challenge.title}
                          </span>
                        </div>
                        <Badge variant="outline">
                          {participant.progress}%
                        </Badge>
                      </div>
                      
                      <Progress value={participant.progress} className="h-1.5" />
                      
                      <p className="mt-2 text-xs text-gray-500 dark:text-gray-400">
                        {challenge.pointsReward} points reward
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-6">
                  <Target className="mx-auto h-10 w-10 text-gray-400 mb-3" />
                  <p className="text-gray-500 dark:text-gray-400">No active challenges</p>
                  <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                    Join a challenge to earn more points
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Achievements Section */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <Trophy className="mr-2 h-5 w-5 text-amber-500" />
            Your Achievements
          </h2>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="unlocked">Unlocked</TabsTrigger>
              <TabsTrigger value="locked">In Progress</TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {achievements.map(achievement => (
                  <AchievementCard key={achievement.id} achievement={achievement} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="unlocked">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {achievements
                  .filter(achievement => achievement.unlocked)
                  .map(achievement => (
                    <AchievementCard key={achievement.id} achievement={achievement} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="locked">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {achievements
                  .filter(achievement => !achievement.unlocked && achievement.progress > 0)
                  .map(achievement => (
                    <AchievementCard key={achievement.id} achievement={achievement} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

interface AchievementCardProps {
  achievement: {
    id: number;
    title: string;
    description: string;
    icon: React.FC<{ className?: string }>;
    progress: number;
    unlocked: boolean;
    date?: string;
    category: string;
  };
}

function AchievementCard({ achievement }: AchievementCardProps) {
  const { title, description, icon: Icon, progress, unlocked, date, category } = achievement;
  
  const categoryColors = {
    learning: "text-primary-600 dark:text-primary-400 bg-primary-100 dark:bg-primary-900/30",
    quiz: "text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/30",
    social: "text-violet-600 dark:text-violet-400 bg-violet-100 dark:bg-violet-900/30",
    streak: "text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30"
  };
  
  const colorClass = categoryColors[category as keyof typeof categoryColors] || categoryColors.learning;

  return (
    <Card className={unlocked ? "" : "opacity-80"}>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className={`p-2 rounded-lg ${colorClass}`}>
            <Icon className="h-5 w-5" />
          </div>
          {unlocked && (
            <Badge className="bg-emerald-500 hover:bg-emerald-600">
              Unlocked
            </Badge>
          )}
        </div>
        <CardTitle className="mt-2 text-base">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        {!unlocked ? (
          <>
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
              <span>Progress</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} />
          </>
        ) : (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-md p-3 text-center">
            <Trophy className="h-8 w-8 mx-auto text-amber-500 mb-2" />
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Unlocked on {date}
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <p className="text-xs text-gray-500 dark:text-gray-400 w-full text-center">
          {unlocked 
            ? "50 points earned" 
            : progress === 0 
              ? "0/50 points" 
              : `${Math.round(progress * 0.5)}/50 points`}
        </p>
      </CardFooter>
    </Card>
  );
}
