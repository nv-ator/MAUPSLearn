import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { YouTubePlayer } from "@/components/ui/youtube-player";
import { Quiz } from "@/components/ui/quiz";
import { apiRequest } from "@/lib/queryClient";
import { Course,  Challenge, Video, ChallengeParticipant } from "@/lib/types";
import { 
  Flame, 
  MessageSquare, 
  Video as VideoIcon, 
  Coins, 
  Users, 
  Calendar, 
  Banknote, 
  BarChart2, 
  CoinsIcon
} from "lucide-react";

const mockUser = {
  id: 1,
  username: "demo",
  displayName: "Demo User",
  avatar: "https://avatar.vercel.sh/demo",
  points: 100,
  streak: 5,
  level: 2
};


export default function Dashboard() {
  // Get courses
  const { data: courses, isLoading: coursesLoading } = useQuery<Course[]>({ 
    queryKey: ['/api/courses'] 
  });

  // Get user challenges
  const { data: userChallenges, isLoading: challengesLoading } = useQuery<{challenge: Challenge, participant: ChallengeParticipant}[]>({ 
    queryKey: ['/api/users/1/challenges'] 
  });

  // Get leaderboard
  const { data: leaderboard, isLoading: leaderboardLoading } = useQuery<User[]>({ 
    queryKey: ['/api/leaderboard'] 
  });

  // Get current course and progress
  const currentCourse = courses?.[0];
  const { data: videos, isLoading: videosLoading } = useQuery<Video[]>({
    queryKey: ['/api/courses/1/videos'],
    enabled: !!currentCourse
  });

  // Get quiz for current video
  const currentVideo = videos?.[0];
  const { data: quiz, isLoading: quizLoading } = useQuery({
    queryKey: ['/api/videos/1/quiz'],
    enabled: !!currentVideo
  });

  const handleQuizComplete = async (score: number, answers: number[]) => {
    if (quiz) {
      try {
        await apiRequest('POST', `/api/quizzes/${quiz.id}/submit`, {
          userId: 1, 
          answers
        });
      } catch (error) {
        console.error("Error submitting quiz:", error);
      }
    }
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Dashboard</h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Your learning progress and recommended content</p>
          </div>
          <div className="mt-3 sm:mt-0">
            <Button>
              <Calendar className="mr-2 h-4 w-4" />
              New Learning Path
            </Button>
          </div>
        </div>

        {/* Progress Section */}
        <div className="mt-8">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                <StatCard 
                  title="Learning Streak" 
                  value={mockUser?.streak?.toString() || "0"} 
                  unit="days" 
                  icon={<Flame className="h-5 w-5" />} 
                  iconColor="text-amber-600" 
                  iconBgColor="bg-amber-500/10" 
                  loading={false}
                />
                <StatCard 
                  title="Quizzes Completed" 
                  value="12" 
                  icon={<MessageSquare className="h-5 w-5" />} 
                  iconColor="text-primary-600" 
                  iconBgColor="bg-primary-500/10" 
                  loading={false}
                />
                <StatCard 
                  title="Videos Watched" 
                  value="23" 
                  icon={<VideoIcon className="h-5 w-5" />} 
                  iconColor="text-emerald-600" 
                  iconBgColor="bg-emerald-500/10" 
                  loading={false}
                />
                <StatCard 
                  title="Points Earned" 
                  value={mockUser?.points?.toString() || "0"} 
                  icon={<Coins className="h-5 w-5" />} 
                  iconColor="text-amber-600" 
                  iconBgColor="bg-amber-500/10" 
                  loading={false}
                />
              </div>

              <div className="mb-2 flex justify-between">
                <h3 className="text-sm font-medium text-gray-700 dark:text-gray-300">Current Course Progress</h3>
                <span className="text-sm text-primary-600 dark:text-primary-400 font-medium">65%</span>
              </div>

              <Progress value={65} className="mb-4" />

              <div className="text-sm">
                <span className="font-medium text-gray-900 dark:text-white">Introduction to FinTech</span>
                <span className="text-gray-500 dark:text-gray-400"> - 3 units left</span>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Continue Learning Section */}
            <div className="lg:col-span-2">
              <Card className="mb-6">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Continue Learning</CardTitle>
                  <Link href="/courses">
                    <a className="text-sm font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400">
                      View all courses
                    </a>
                  </Link>
                </CardHeader>
                <CardContent>
                  {/* Current Video */}
                  <div className="mb-6">
                    {videosLoading ? (
                      <Skeleton className="w-full aspect-video rounded-lg mb-4" />
                    ) : currentVideo ? (
                      <YouTubePlayer
                        videoId={currentVideo.videoId}
                        title={currentVideo.title}
                        className="mb-4"
                      />
                    ) : (
                      <div className="w-full aspect-video bg-gray-200 dark:bg-gray-700 rounded-lg mb-4 flex items-center justify-center">
                        <p className="text-gray-500 dark:text-gray-400">No video available</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          {currentVideo?.title || "Video not found"}
                        </h3>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          by Sarah Johnson • Last watched yesterday
                        </p>
                      </div>
                      <div>
                        <Button>Continue</Button>
                      </div>
                    </div>
                  </div>

                  {/* Quiz Section */}
                  <div className="mb-6">
                    {quizLoading ? (
                      <Skeleton className="w-full h-64 rounded-lg" />
                    ) : quiz ? (
                      <Quiz
                        questions={quiz.questions}
                        onComplete={handleQuizComplete}
                      />
                    ) : null}
                  </div>

                  {/* Next Up Videos */}
                  <h3 className="font-medium text-gray-900 dark:text-white mb-3">Next in this course</h3>

                  {videosLoading ? (
                    <div className="space-y-4">
                      <Skeleton className="w-full h-16" />
                      <Skeleton className="w-full h-16" />
                    </div>
                  ) : videos && videos.length > 1 ? (
                    <div className="space-y-4">
                      {videos.slice(1, 3).map((video) => (
                        <div key={video.id} className="flex items-start space-x-4">
                          <div className="flex-shrink-0 w-24 h-16 rounded bg-gray-200 dark:bg-gray-700 overflow-hidden">
                            <img
                              src={video.thumbnail}
                              alt={video.title}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="text-sm font-medium text-gray-900 dark:text-white truncate">
                              {video.title}
                            </h4>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')} • Module {video.position}
                            </p>
                            <div className="mt-1 w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5">
                              <div
                                className="bg-gray-400 dark:bg-gray-500 h-1.5 rounded-full"
                                style={{ width: '0%' }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 dark:text-gray-400 text-sm">No more videos in this course</p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Right Sidebar Content */}
            <div className="space-y-6">
              {/* Challenges Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Active Challenges</CardTitle>
                </CardHeader>
                <CardContent>
                  {challengesLoading ? (
                    <div className="space-y-4">
                      <Skeleton className="w-full h-32" />
                      <Skeleton className="w-full h-32" />
                    </div>
                  ) : userChallenges && userChallenges.length > 0 ? (
                    <div className="space-y-4">
                      {userChallenges.map(({ challenge, participant }) => (
                        <div key={challenge.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex items-center">
                              <span className="flex-shrink-0 h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center text-primary-600 dark:text-primary-400">
                                {challenge.isTeamChallenge ? (
                                  <Users className="h-5 w-5" />
                                ) : (
                                  <Calendar className="h-5 w-5" />
                                )}
                              </span>
                              <div className="ml-3">
                                <h3 className="text-sm font-medium text-gray-900 dark:text-white">{challenge.title}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400">
                                  {challenge.isTeamChallenge ? '4 team members' : 'Day 7 of 30'} • 
                                  {new Date(challenge.endDate) > new Date() 
                                    ? ` ${Math.ceil((new Date(challenge.endDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left` 
                                    : ' Ended'}
                                </p>
                              </div>
                            </div>
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 dark:bg-amber-900 text-amber-800 dark:text-amber-300">
                              Active
                            </span>
                          </div>

                          <div className="mt-3">
                            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                              <span>{challenge.isTeamChallenge ? 'Team Progress' : 'Your Progress'}</span>
                              <span>{participant.progress}%</span>
                            </div>
                            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${challenge.isTeamChallenge ? 'bg-amber-500' : 'bg-emerald-500'}`}
                                style={{ width: `${participant.progress}%` }}
                              ></div>
                            </div>
                          </div>

                          <div className="mt-3">
                            <Button variant="secondary" className="w-full">
                              {challenge.isTeamChallenge ? 'View Challenge' : 'Continue Challenge'}
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-500 dark:text-gray-400 mb-4">No active challenges</p>
                      <Button variant="outline">Join a Challenge</Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Leaderboard Section */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Leaderboard</CardTitle>
                  <Link href="/community">
                    <a className="text-sm font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400">
                      See all
                    </a>
                  </Link>
                </CardHeader>
                <CardContent>
                  {leaderboardLoading ? (
                    <div className="space-y-3">
                      <Skeleton className="w-full h-10" />
                      <Skeleton className="w-full h-10" />
                      <Skeleton className="w-full h-10" />
                      <Skeleton className="w-full h-10" />
                    </div>
                  ) : leaderboard ? (
                    <div className="space-y-2">
                      {leaderboard.map((user, index) => (
                        <div 
                          key={user.id} 
                          className={`flex items-center p-2 rounded-lg ${
                            user.id === mockUser.id 
                              ? 'bg-primary-50 dark:bg-primary-900/20' 
                              : 'hover:bg-gray-50 dark:hover:bg-gray-700'
                            }`}
                        >
                          <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-amber-100 dark:bg-amber-900/30 text-amber-600 dark:text-amber-500 font-semibold text-sm">
                            {index + 1}
                          </div>
                          <div className="ml-3 flex-1 flex items-center justify-between">
                            <div className="flex items-center">
                              <img 
                                className="h-8 w-8 rounded-full" 
                                src={user.avatar || `https://ui-avatars.com/api/?name=${user.displayName}`} 
                                alt={`${user.displayName} avatar`}
                              />
                              <span className="ml-2 text-sm font-medium text-gray-900 dark:text-white">
                                {user.displayName}
                              </span>
                              {user.id === mockUser.id && (
                                <span className="ml-1 text-xs text-gray-500 dark:text-gray-400">(You)</span>
                              )}
                            </div>
                            <span className="text-sm font-medium text-gray-900 dark:text-white">
                              {user.points} pts
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                      Failed to load leaderboard
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Recommended Paths Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Paths</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <RecommendedPath
                      title="Banking Technology"
                      description="8 courses • Beginner to Intermediate"
                      icon={<Banknote className="h-5 w-5" />}
                      iconColor="text-primary-600 dark:text-primary-400"
                      iconBgColor="bg-primary-100 dark:bg-primary-900/30"
                    />

                    <RecommendedPath
                      title="Cryptocurrency Fundamentals"
                      description="6 courses • All levels"
                      icon={<CoinsIcon className="h-5 w-5" />}
                      iconColor="text-amber-600 dark:text-amber-500"
                      iconBgColor="bg-amber-100 dark:bg-amber-900/30"
                    />

                    <RecommendedPath
                      title="Financial Analysis"
                      description="10 courses • Intermediate to Advanced"
                      icon={<BarChart2 className="h-5 w-5" />}
                      iconColor="text-emerald-600 dark:text-emerald-500"
                      iconBgColor="bg-emerald-100 dark:bg-emerald-900/30"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  unit?: string;
  icon: React.ReactNode;
  iconColor: string;
  iconBgColor: string;
  loading?: boolean;
}

function StatCard({ title, value, unit, icon, iconColor, iconBgColor, loading = false }: StatCardProps) {
  if (loading) {
    return (
      <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-8 w-16" />
          </div>
          <Skeleton className="h-10 w-10 rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-semibold">
            {value} {unit && <span className="text-base font-normal">{unit}</span>}
          </p>
        </div>
        <span className={`${iconBgColor} ${iconColor} p-2 rounded-full`}>
          {icon}
        </span>
      </div>
    </div>
  );
}

interface RecommendedPathProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  iconColor: string;
  iconBgColor: string;
}

function RecommendedPath({ title, description, icon, iconColor, iconBgColor }: RecommendedPathProps) {
  return (
    <Link href={`/courses?category=${encodeURIComponent(title)}`}>
      <a className="block group">
        <div className="flex items-center p-3 border border-gray-200 dark:border-gray-700 rounded-lg group-hover:bg-gray-50 dark:group-hover:bg-gray-700">
          <span className={`flex-shrink-0 h-10 w-10 rounded-full ${iconBgColor} flex items-center justify-center ${iconColor}`}>
            {icon}
          </span>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400">
              {title}
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">{description}</p>
          </div>
        </div>
      </a>
    </Link>
  );
}