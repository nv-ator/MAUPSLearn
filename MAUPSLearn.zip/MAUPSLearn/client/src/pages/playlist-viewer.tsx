import { useState } from 'react';
import { useParams, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { YoutubePlaylistWrapper } from '@/components/ui/youtube-playlist-wrapper';
import { ChevronLeft, Youtube } from 'lucide-react';

export default function PlaylistViewer() {
  const { playlistId } = useParams();
  const [selectedVideoId, setSelectedVideoId] = useState<string | null>(null);
  const [selectedVideoTitle, setSelectedVideoTitle] = useState<string | null>(null);

  const handleVideoSelect = (videoId: string, videoTitle?: string) => {
    setSelectedVideoId(videoId);
    setSelectedVideoTitle(videoTitle || null);
    console.log('Selected video:', videoId, 'with title:', videoTitle);
    // In a real app, you might want to save the user's last watched video
    // or update progress information here
  };

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header with back button */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex items-center">
          <Link 
            href="/dashboard"
            className="inline-flex items-center mr-4 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Back to Dashboard
          </Link>
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">
            YouTube Playlist Viewer
          </h1>
        </div>

        <div className="mt-6">
          {/* Playlist Player */}
          {playlistId ? (
            <YoutubePlaylistWrapper
              initialPlaylistId={playlistId}
              showUrlInput={false}
              autoplay={false}
              maxVideos={20}
              onVideoSelect={handleVideoSelect}
            />
          ) : (
            <YoutubePlaylistWrapper
              showUrlInput={true}
              autoplay={false}
              maxVideos={20}
              onVideoSelect={handleVideoSelect}
            />
          )}

          {/* Additional Content */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">About This Feature</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  The YouTube Playlist Viewer allows you to easily explore educational content from YouTube.
                  Simply paste a YouTube playlist URL above to start learning.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Learning Tips</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-2">
                  <li>• Take notes while watching the videos</li>
                  <li>• Pause and reflect on key concepts</li>
                  <li>• Try to explain what you've learned in your own words</li>
                  <li>• Apply concepts through practical exercises</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Recommended Playlists</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Link href="/playlist/PLIhvC56v63IJVXv0GJcl9vO5Z6znCVb1P">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                    >
                      <Youtube className="h-4 w-4 mr-2" />
                      <span className="truncate">Network Engineering Basics</span>
                    </Button>
                  </Link>
                  <Link href="/playlist/PLUl4u3cNGP61Oq3tWYp6V_F-5jb5L2iHb">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                    >
                      <Youtube className="h-4 w-4 mr-2" />
                      <span className="truncate">MIT Finance Theory</span>
                    </Button>
                  </Link>
                  <Link href="/playlist/PLUl4u3cNGP63ctJIEC1UnZ0btsphnnoHR">
                    <Button 
                      variant="outline" 
                      className="w-full justify-start"
                    >
                      <Youtube className="h-4 w-4 mr-2" />
                      <span className="truncate">MIT FinTech</span>
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}