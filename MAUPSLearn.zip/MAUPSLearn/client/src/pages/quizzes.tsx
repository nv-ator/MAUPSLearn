import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Quiz } from "@/components/ui/quiz";
import { QuizResult, Video, Course } from "@/lib/types";
import { CheckCircle2, Clock, HelpCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Quizzes() {
  const [activeTab, setActiveTab] = useState("available");
  const [selectedVideo, setSelectedVideo] = useState<number | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);

  // Fetch courses
  const { data: courses, isLoading: coursesLoading } = useQuery<Course[]>({
    queryKey: ['/api/courses']
  });

  // Fetch videos when we have courses
  const { data: videos, isLoading: videosLoading } = useQuery<Video[]>({
    queryKey: ['/api/courses/1/videos'],
    enabled: !!courses && courses.length > 0
  });

  // Fetch quiz results for the current user
  const { data: quizResults, isLoading: resultsLoading } = useQuery<QuizResult[]>({
    queryKey: ['/api/users/1/quiz-results']
  });

  // Fetch specific quiz when a video is selected
  const { data: quiz, isLoading: quizLoading } = useQuery({
    queryKey: ['/api/videos', selectedVideo, 'quiz'],
    enabled: !!selectedVideo && showQuiz
  });

  const handleStartQuiz = (videoId: number) => {
    setSelectedVideo(videoId);
    setShowQuiz(true);
  };

  const handleQuizComplete = async (score: number, answers: number[]) => {
    if (quiz && selectedVideo) {
      try {
        await apiRequest('POST', `/api/quizzes/${quiz.id}/submit`, {
          userId: 1, // In a real app, get from auth context
          answers
        });
        // Reset state to show available quizzes
        setShowQuiz(false);
        setSelectedVideo(null);
        // Invalidate quiz results to refresh the list
        // queryClient.invalidateQueries({queryKey: ['/api/users/1/quiz-results']});
      } catch (error) {
        console.error("Error submitting quiz:", error);
      }
    }
  };

  // If a quiz is being shown, render it
  if (showQuiz && selectedVideo) {
    return (
      <div className="py-6">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 md:px-8">
          <Button 
            variant="outline" 
            onClick={() => setShowQuiz(false)} 
            className="mb-4"
          >
            Back to Quizzes
          </Button>
          
          {quizLoading ? (
            <Skeleton className="w-full h-[500px] rounded-lg" />
          ) : quiz ? (
            <Quiz 
              questions={quiz.questions} 
              onComplete={handleQuizComplete} 
            />
          ) : (
            <Card>
              <CardContent className="pt-6 text-center">
                <HelpCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white">Quiz not found</h3>
                <p className="text-gray-500 dark:text-gray-400 mt-2">
                  We couldn't load this quiz. Please try again later.
                </p>
                <Button 
                  onClick={() => setShowQuiz(false)} 
                  className="mt-4"
                >
                  Go Back
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        {/* Header */}
        <div className="pb-5 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-white">Quizzes</h1>
            <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">Test your knowledge with AI-generated quizzes</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-6">
          <Tabs defaultValue="available" onValueChange={setActiveTab} value={activeTab}>
            <TabsList className="grid w-full max-w-md grid-cols-2">
              <TabsTrigger value="available">Available Quizzes</TabsTrigger>
              <TabsTrigger value="completed">Completed Quizzes</TabsTrigger>
            </TabsList>

            {/* Available Quizzes */}
            <TabsContent value="available" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {coursesLoading || videosLoading ? (
                  // Loading skeletons
                  Array.from({ length: 6 }).map((_, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <Skeleton className="h-5 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-full" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-32 w-full rounded-md" />
                      </CardContent>
                      <CardFooter>
                        <Skeleton className="h-9 w-full" />
                      </CardFooter>
                    </Card>
                  ))
                ) : videos && videos.length > 0 ? (
                  videos.map((video) => (
                    <Card key={video.id}>
                      <CardHeader>
                        <CardTitle>{video.title}</CardTitle>
                        <CardDescription>
                          {courses?.find(c => c.id === video.courseId)?.title}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-video rounded-md overflow-hidden bg-gray-200 dark:bg-gray-700 mb-4">
                          <img 
                            src={video.thumbnail} 
                            alt={video.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')} minutes
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button 
                          className="w-full"
                          onClick={() => handleStartQuiz(video.id)}
                        >
                          Take Quiz
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full text-center py-12">
                    <HelpCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">No quizzes available</h3>
                    <p className="text-gray-500 dark:text-gray-400 mt-2">
                      Watch some videos first to unlock quizzes
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Completed Quizzes */}
            <TabsContent value="completed" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {resultsLoading ? (
                  // Loading skeletons
                  Array.from({ length: 3 }).map((_, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-3">
                        <Skeleton className="h-5 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-full" />
                      </CardHeader>
                      <CardContent>
                        <Skeleton className="h-24 w-full rounded-md" />
                      </CardContent>
                      <CardFooter>
                        <Skeleton className="h-4 w-full" />
                      </CardFooter>
                    </Card>
                  ))
                ) : quizResults && quizResults.length > 0 ? (
                  quizResults.map((result) => (
                    <Card key={result.id}>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-base">
                            {videos?.find(v => v.id === result.quizId)?.title || "Quiz"}
                          </CardTitle>
                          <div className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 rounded-full p-1">
                            <CheckCircle2 className="h-5 w-5" />
                          </div>
                        </div>
                        <CardDescription>
                          Completed on {new Date(result.completedAt).toLocaleDateString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="text-center p-4">
                          <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400 mb-3">
                            <span className="text-2xl font-bold">
                              {Math.round((result.score / result.totalQuestions) * 100)}%
                            </span>
                          </div>
                          <p className="text-sm font-medium">
                            Score: {result.score}/{result.totalQuestions}
                          </p>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <p className="text-xs text-gray-500 dark:text-gray-400 text-center w-full">
                          You earned {result.score * 10} points from this quiz
                        </p>
                      </CardFooter>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full text-center py-12">
                    <HelpCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white">No completed quizzes</h3>
                    <p className="text-gray-500 dark:text-gray-400 mt-2">
                      Take some quizzes to see your results here
                    </p>
                    <Button
                      onClick={() => setActiveTab("available")}
                      variant="outline"
                      className="mt-4"
                    >
                      Go to Available Quizzes
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
