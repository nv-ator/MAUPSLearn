#!/bin/bash
npx tsx server/start-tunnel.ts