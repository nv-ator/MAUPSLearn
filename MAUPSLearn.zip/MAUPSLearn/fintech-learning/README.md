# FinTech Learning Platform Prototype

This is a standalone web-based learning interface prototype for a FinTech educational platform. The prototype demonstrates a simplified version of the main platform's functionality, focusing on delivering educational content through YouTube videos and generating interactive quizzes.

## Features

1. **Video Catalog**
   - Browse a collection of curated FinTech educational videos
   - Filter videos by category (Budgeting, UPI, Investing, etc.)
   - Filter by experience level (Beginner, Intermediate, Advanced)
   - Search for specific video titles

2. **AI-Powered Quiz Generator**
   - Generate topic-specific quizzes for any video
   - Answer multiple-choice questions to test your knowledge
   - Get immediate feedback on your quiz performance
   - View the correct answers after submission

3. **Responsive Design**
   - Works on desktop, tablet, and mobile devices
   - Clean, modern interface with FinTech-themed colors

## How to Use

1. Open `index.html` in any modern web browser
2. Browse the video catalog or use filters to find specific content
3. Click on "Generate Quiz" for any video to test your knowledge
4. Answer the questions and click "Submit Quiz" to see your results

## Technical Details

- Built with vanilla HTML, CSS, and JavaScript
- No external libraries or frameworks required
- Simulates AI-generated quizzes with pre-defined question sets
- YouTube videos embedded via iframes

## Future Enhancements

- Integration with a real AI API for dynamic quiz generation
- User accounts and progress tracking
- Certificate generation for completed courses
- Social sharing features
- More advanced analytics and personalized learning paths
