// Course Data - Structure for organizing videos into courses
const courses = [
    {
        id: 101,
        title: "Crypto Trading for Beginners",
        description: "An introductory course covering the basics of cryptocurrency, how to start trading, and understanding market trends.",
        category: "FinTech",
        level: "Beginner",
        courseLink: "https://youtube.com/playlist?list=PLAAsdVgd9DsLLTBsIHEoE8VJzCdVBXYBE&si=kLMK82RPfACmRffR",
        playlistEmbedUrl: "https://www.youtube.com/embed/videoseries?list=PLAAsdVgd9DsLLTBsIHEoE8VJzCdVBXYBE",
        thumbnail: "https://img.youtube.com/vi/MwP-omMwd3A/hqdefault.jpg" // Thumbnail from first video in playlist
    }
];

// Video Data - Array of video objects with course associations
const videos = [
    {
        id: 1001,
        courseId: 101,
        title: "What is Cryptocurrency? Bitcoin, Ethereum, and More",
        videoUrl: "https://www.youtube.com/embed/MwP-omMwd3A",
        category: "FinTech",
        level: "Beginner",
        description: "An introduction to the fundamental concepts of cryptocurrency, including Bitcoin, Ethereum, and other popular digital currencies."
    },
    {
        id: 1002,
        courseId: 101,
        title: "How to Set Up Your First Crypto Wallet",
        videoUrl: "https://www.youtube.com/embed/PYCJrpZB2Oo",
        category: "FinTech",
        level: "Beginner",
        description: "A step-by-step guide to setting up and securing your first cryptocurrency wallet."
    },
    {
        id: 1003,
        courseId: 101,
        title: "Understanding Crypto Exchanges",
        videoUrl: "https://www.youtube.com/embed/dBJPAeOlF2o",
        category: "FinTech",
        level: "Beginner",
        description: "Learn about different cryptocurrency exchanges, their features, and how to choose the right one for your trading needs."
    },
    {
        id: 1004,
        courseId: 101,
        title: "Basic Trading Strategies for Beginners",
        videoUrl: "https://www.youtube.com/embed/LnQB63E5Vg4",
        category: "FinTech",
        level: "Beginner",
        description: "Introduction to fundamental crypto trading strategies that are suitable for beginners, including dollar-cost averaging and more."
    },
    {
        id: 1005,
        courseId: 101,
        title: "Reading Crypto Charts for Beginners",
        videoUrl: "https://www.youtube.com/embed/szs9J-iYJk4",
        category: "FinTech",
        level: "Beginner",
        description: "Learn how to read and interpret cryptocurrency charts and understand basic technical analysis concepts."
    }
];

// Quiz questions by category for the mock AI generator
const quizQuestionsByCategory = {
    "FinTech": [
        {
            question: "What is the primary technology behind most cryptocurrencies?",
            options: [
                "Cloud computing",
                "Blockchain",
                "Artificial intelligence",
                "5G networks"
            ],
            correctIndex: 1
        },
        {
            question: "Which of the following is NOT typically a feature of a crypto wallet?",
            options: [
                "Storing private keys",
                "Processing credit card payments",
                "Managing multiple cryptocurrencies",
                "Generating public addresses"
            ],
            correctIndex: 1
        },
        {
            question: "What is a 'cold wallet' in cryptocurrency?",
            options: [
                "A wallet with no funds",
                "A wallet that hasn't been used recently",
                "A hardware storage device not connected to the internet",
                "A wallet for storing stablecoins"
            ],
            correctIndex: 2
        },
        {
            question: "What is dollar-cost averaging in crypto investing?",
            options: [
                "Converting all cryptocurrencies to US dollars",
                "Investing a fixed amount at regular intervals regardless of price",
                "Only buying crypto when it reaches a specific dollar value",
                "Matching each crypto purchase with an equal dollar investment"
            ],
            correctIndex: 1
        },
        {
            question: "What does a candlestick chart show in crypto trading?",
            options: [
                "Only the closing prices for each time period",
                "Network hash rates over time",
                "Opening, closing, high, and low prices for each time period",
                "Transaction volumes only"
            ],
            correctIndex: 2
        }
    ],
    "Budgeting": [
        {
            question: "What is the primary purpose of creating a personal budget?",
            options: [
                "To impress financial advisors",
                "To track and manage income and expenses",
                "To qualify for more credit cards",
                "To reduce your tax liability"
            ],
            correctIndex: 1
        },
        {
            question: "Which of the following is NOT typically part of a 50/30/20 budget?",
            options: [
                "50% for needs like housing and utilities",
                "30% for wants like entertainment",
                "20% for savings and debt repayment",
                "20% for cryptocurrency investments"
            ],
            correctIndex: 3
        },
        {
            question: "What is a zero-based budget?",
            options: [
                "A budget where you spend nothing",
                "A budget where every dollar has a specific job",
                "A budget focused only on paying off debt",
                "A budget that only tracks expenses, not income"
            ],
            correctIndex: 1
        }
    ],
    "Investing": [
        {
            question: "Which investment type typically has the highest risk and potential return?",
            options: [
                "Government bonds",
                "High-yield savings accounts",
                "Index funds",
                "Individual stocks"
            ],
            correctIndex: 3
        },
        {
            question: "What is diversification in investing?",
            options: [
                "Investing in one company over a long period",
                "Spreading investments across various assets to reduce risk",
                "Changing investment strategies frequently",
                "Investing only in foreign markets"
            ],
            correctIndex: 1
        },
        {
            question: "What is the rule of 72 used for in investing?",
            options: [
                "To calculate your risk tolerance score",
                "To determine your asset allocation",
                "To estimate how long it takes for an investment to double",
                "To calculate capital gains tax"
            ],
            correctIndex: 2
        }
    ],
    "UPI": [
        {
            question: "What does UPI stand for?",
            options: [
                "Universal Payment Interface",
                "Unified Payment Interface",
                "Universal Public Integration",
                "Unified Processing Interface"
            ],
            correctIndex: 1
        },
        {
            question: "Which of the following is required to use UPI services?",
            options: [
                "International credit card",
                "Blockchain wallet",
                "Bank account linked to mobile number",
                "Cryptocurrency assets"
            ],
            correctIndex: 2
        },
        {
            question: "What is a primary advantage of UPI over traditional online banking?",
            options: [
                "It requires an internet connection",
                "It works only during banking hours",
                "It enables immediate 24/7 fund transfers",
                "It charges higher transaction fees"
            ],
            correctIndex: 2
        }
    ],
    "Banking": [
        {
            question: "What is a key feature of digital banking that traditional banking typically doesn't offer?",
            options: [
                "FDIC insurance on deposits",
                "24/7 account access and transactions",
                "Interest on savings accounts",
                "The ability to withdraw cash"
            ],
            correctIndex: 1
        },
        {
            question: "What is a neobank?",
            options: [
                "A traditional bank with an online portal",
                "A digital-only bank without physical branches",
                "A microfinance institution",
                "A central bank subsidiary"
            ],
            correctIndex: 1
        },
        {
            question: "Which of the following is typically NOT a feature of mobile banking apps?",
            options: [
                "Checking account balances",
                "Mobile check deposits",
                "Physical cash deposits",
                "Bill payments"
            ],
            correctIndex: 2
        }
    ],
    "Cryptocurrency": [
        {
            question: "What technology underlies most cryptocurrencies?",
            options: [
                "Artificial intelligence",
                "Cloud computing",
                "Blockchain",
                "Quantum computing"
            ],
            correctIndex: 2
        },
        {
            question: "What is a key characteristic of DeFi (Decentralized Finance)?",
            options: [
                "It requires approval from central banks",
                "It eliminates intermediaries like banks",
                "It can only be used with Bitcoin",
                "It is controlled by a single organization"
            ],
            correctIndex: 1
        },
        {
            question: "What is a smart contract in blockchain technology?",
            options: [
                "A legal agreement written by lawyers",
                "A self-executing contract with the terms directly written into code",
                "A contract that requires biometric verification",
                "A financial instrument regulated by central banks"
            ],
            correctIndex: 1
        },
        {
            question: "What is the main difference between a Central Bank Digital Currency (CBDC) and cryptocurrency?",
            options: [
                "CBDCs are always built on blockchain technology",
                "Cryptocurrencies are issued by governments",
                "CBDCs are issued and regulated by central authorities",
                "Cryptocurrencies can only be used for illegal activities"
            ],
            correctIndex: 2
        },
        {
            question: "What is the primary innovation of blockchain technology?",
            options: [
                "It allows for instant payments without transaction fees",
                "It enables decentralized, tamper-resistant record-keeping without a central authority",
                "It makes all financial transactions completely anonymous",
                "It eliminates the need for computers in financial transactions"
            ],
            correctIndex: 1
        },
        {
            question: "Which of the following best describes the consensus mechanism used in Bitcoin?",
            options: [
                "Proof of Identity",
                "Proof of Authority",
                "Proof of Stake",
                "Proof of Work"
            ],
            correctIndex: 3
        }
    ],
    "Entrepreneurship": [
        {
            question: "What is a key advantage of FinTech startups over traditional financial institutions?",
            options: [
                "They have larger customer bases",
                "They have more regulatory oversight",
                "They can iterate and innovate more quickly",
                "They have access to more capital"
            ],
            correctIndex: 2
        },
        {
            question: "What is the 'regulatory sandbox' concept in FinTech?",
            options: [
                "A playroom for financial regulators",
                "A controlled testing environment for new financial products",
                "A social network for FinTech entrepreneurs",
                "A ban on certain types of financial innovation"
            ],
            correctIndex: 1
        },
        {
            question: "Which funding source typically provides the earliest investment for FinTech startups?",
            options: [
                "Venture capital firms",
                "Investment banks",
                "Angel investors",
                "Initial public offerings (IPOs)"
            ],
            correctIndex: 2
        }
    ],
    "Compliance": [
        {
            question: "What does KYC stand for in financial services?",
            options: [
                "Keep Your Cash",
                "Know Your Customer",
                "Key Yield Calculation",
                "Knowledge Yield Curve"
            ],
            correctIndex: 1
        },
        {
            question: "What is RegTech primarily designed to do?",
            options: [
                "Increase regulatory burdens on banks",
                "Eliminate the need for compliance officers",
                "Streamline regulatory compliance processes",
                "Replace government regulators with AI"
            ],
            correctIndex: 2
        },
        {
            question: "Which technology is commonly used in anti-money laundering compliance?",
            options: [
                "Virtual reality",
                "Artificial intelligence and machine learning",
                "5G networks",
                "Quantum computing"
            ],
            correctIndex: 1
        }
    ]
};

// DOM Elements
const courseCatalog = document.getElementById('course-catalog');
const videoCatalog = document.getElementById('video-catalog');
const searchInput = document.getElementById('search-input');
const searchButton = document.getElementById('search-button');
const categoryFilter = document.getElementById('category-filter');
const levelFilter = document.getElementById('level-filter');
const courseFilter = document.getElementById('course-filter');
const applyFiltersBtn = document.getElementById('apply-filters');
const resetFiltersBtn = document.getElementById('reset-filters');
const quizContainer = document.getElementById('quiz-container');
const quizTitle = document.getElementById('quiz-title');
const quizContent = document.getElementById('quiz-content');
const submitQuizBtn = document.getElementById('submit-quiz');
const closeQuizBtn = document.getElementById('close-quiz');
const quizResults = document.getElementById('quiz-results');

// State variables
let currentCourseId = null;
let currentQuiz = {
    videoId: null,
    questions: [],
    selectedAnswers: [],
    score: 0
};

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    // Populate course catalog
    displayCourses();
    
    // Populate course filter dropdown
    populateCourseFilter();
    
    // Display all videos initially
    displayVideos(videos);
    
    // Setup event listeners
    setupEventListeners();
});

// Display videos in the catalog
function displayVideos(videosToDisplay) {
    videoCatalog.innerHTML = '';
    
    if (videosToDisplay.length === 0) {
        videoCatalog.innerHTML = '<div class="no-results">No videos match your search criteria. Try different filters.</div>';
        return;
    }
    
    videosToDisplay.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <div class="video-iframe-container">
                <iframe src="${video.videoUrl}" title="${video.title}" allowfullscreen></iframe>
            </div>
            <div class="video-info">
                <h3 class="video-title">${video.title}</h3>
                <div class="video-meta">
                    <span class="category-tag">${video.category}</span>
                    <span class="level-tag">${video.level}</span>
                </div>
                <button class="btn quiz-btn" data-video-id="${video.id}">Generate Quiz</button>
            </div>
        `;
        videoCatalog.appendChild(videoCard);
    });
}

// Setup event listeners
function setupEventListeners() {
    // Search button click
    searchButton.addEventListener('click', filterVideos);
    
    // Search input enter key
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            filterVideos();
        }
    });
    
    // Apply filters button
    applyFiltersBtn.addEventListener('click', filterVideos);
    
    // Reset filters button
    resetFiltersBtn.addEventListener('click', resetFilters);
    
    // Generate quiz buttons (using event delegation)
    videoCatalog.addEventListener('click', (e) => {
        if (e.target.classList.contains('quiz-btn')) {
            const videoId = parseInt(e.target.dataset.videoId);
            generateQuiz(videoId);
        }
    });
    
    // Course embed buttons (using event delegation)
    courseCatalog.addEventListener('click', (e) => {
        if (e.target.classList.contains('embed-btn')) {
            e.stopPropagation(); // Prevent triggering the courseCard click event
            
            const embedUrl = e.target.dataset.embedUrl;
            showPlaylistEmbed(embedUrl);
        }
    });
    
    // Submit quiz button
    submitQuizBtn.addEventListener('click', submitQuiz);
    
    // Close quiz button
    closeQuizBtn.addEventListener('click', closeQuiz);
}

// Display courses in the catalog
function displayCourses() {
    courseCatalog.innerHTML = '';
    
    courses.forEach(course => {
        const courseCard = document.createElement('div');
        courseCard.className = 'course-card';
        courseCard.dataset.courseId = course.id;
        
        courseCard.innerHTML = `
            <div class="course-thumbnail">
                <img src="${course.thumbnail || 'https://via.placeholder.com/300x169?text=Course+Thumbnail'}" alt="${course.title}">
            </div>
            <div class="course-info">
                <h3 class="course-title">${course.title}</h3>
                <p class="course-description">${course.description}</p>
                <div class="course-meta">
                    <span class="course-category">${course.category}</span>
                    <span class="course-level">${course.level}</span>
                </div>
                <div class="course-actions">
                    <a href="${course.courseLink}" target="_blank" class="btn view-btn">View on YouTube</a>
                    <button class="btn embed-btn" data-embed-url="${course.playlistEmbedUrl}">Watch Playlist</button>
                </div>
            </div>
        `;
        
        // Add click event to show course videos
        courseCard.addEventListener('click', () => {
            currentCourseId = course.id;
            courseFilter.value = course.id;
            filterVideos();
        });
        
        courseCatalog.appendChild(courseCard);
    });
}

// Populate course filter dropdown
function populateCourseFilter() {
    courseFilter.innerHTML = '<option value="all">All Courses</option>';
    
    courses.forEach(course => {
        const option = document.createElement('option');
        option.value = course.id;
        option.textContent = course.title;
        courseFilter.appendChild(option);
    });
    
    // Add change event to course filter
    courseFilter.addEventListener('change', () => {
        currentCourseId = courseFilter.value === 'all' ? null : parseInt(courseFilter.value);
        filterVideos();
    });
}

// Filter videos based on search and filter criteria
function filterVideos() {
    const searchTerm = searchInput.value.toLowerCase();
    const categoryValue = categoryFilter.value;
    const levelValue = levelFilter.value;
    const courseValue = currentCourseId || (courseFilter.value === 'all' ? null : parseInt(courseFilter.value));
    
    const filteredVideos = videos.filter(video => {
        // Filter by search term
        const matchesSearch = video.title.toLowerCase().includes(searchTerm) || 
                             video.description.toLowerCase().includes(searchTerm);
        
        // Filter by category
        const matchesCategory = categoryValue === 'all' || video.category === categoryValue;
        
        // Filter by level
        const matchesLevel = levelValue === 'all' || video.level === levelValue;
        
        // Filter by course
        const matchesCourse = !courseValue || video.courseId === courseValue;
        
        return matchesSearch && matchesCategory && matchesLevel && matchesCourse;
    });
    
    displayVideos(filteredVideos);
}

// Reset all filters and display all videos
function resetFilters() {
    searchInput.value = '';
    categoryFilter.value = 'all';
    levelFilter.value = 'all';
    courseFilter.value = 'all';
    currentCourseId = null;
    
    displayVideos(videos);
}

// Generate a quiz for a specific video
function generateQuiz(videoId) {
    const video = videos.find(v => v.id === videoId);
    
    if (!video) return;
    
    quizTitle.textContent = video.title;
    
    // Simulating AI-generated quiz by selecting relevant questions based on video category
    let questionPool = quizQuestionsByCategory[video.category] || [];
    
    // If no questions for the specific category, use a random category
    if (questionPool.length === 0) {
        const categories = Object.keys(quizQuestionsByCategory);
        const randomCategory = categories[Math.floor(Math.random() * categories.length)];
        questionPool = quizQuestionsByCategory[randomCategory];
    }
    
    // Select 3 random questions if more are available
    let selectedQuestions = [];
    if (questionPool.length <= 3) {
        selectedQuestions = [...questionPool];
    } else {
        // Randomly select 3 questions
        const indices = new Set();
        while (indices.size < 3) {
            indices.add(Math.floor(Math.random() * questionPool.length));
        }
        selectedQuestions = Array.from(indices).map(index => questionPool[index]);
    }
    
    // Set current quiz state
    currentQuiz = {
        videoId: videoId,
        questions: selectedQuestions,
        selectedAnswers: new Array(selectedQuestions.length).fill(null),
        score: 0
    };
    
    // Generate quiz HTML
    renderQuizQuestions();
    
    // Show quiz container
    quizContainer.classList.remove('hidden');
    quizResults.classList.add('hidden');
}

// Render the quiz questions
function renderQuizQuestions() {
    quizContent.innerHTML = '';
    
    currentQuiz.questions.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question';
        
        let optionsHTML = '';
        question.options.forEach((option, optIndex) => {
            const isSelected = currentQuiz.selectedAnswers[index] === optIndex;
            const selectedClass = isSelected ? 'selected' : '';
            
            optionsHTML += `
                <div class="option ${selectedClass}" data-question="${index}" data-option="${optIndex}">
                    <input type="radio" id="q${index}o${optIndex}" name="question${index}" ${isSelected ? 'checked' : ''}>
                    <label for="q${index}o${optIndex}">${option}</label>
                </div>
            `;
        });
        
        questionDiv.innerHTML = `
            <div class="question-text">Question ${index + 1}: ${question.question}</div>
            <div class="options">${optionsHTML}</div>
        `;
        
        quizContent.appendChild(questionDiv);
    });
    
    // Add option selection event listeners
    const options = document.querySelectorAll('.option');
    options.forEach(option => {
        option.addEventListener('click', selectOption);
    });
}

// Handle option selection
function selectOption(e) {
    const option = e.currentTarget;
    const questionIndex = parseInt(option.dataset.question);
    const optionIndex = parseInt(option.dataset.option);
    
    // Update selected answer
    currentQuiz.selectedAnswers[questionIndex] = optionIndex;
    
    // Update UI to show selected option
    const questionOptions = document.querySelectorAll(`.option[data-question="${questionIndex}"]`);
    questionOptions.forEach(opt => opt.classList.remove('selected'));
    option.classList.add('selected');
    
    // Update radio button
    const radioButton = option.querySelector('input[type="radio"]');
    radioButton.checked = true;
}

// Submit quiz and show results
function submitQuiz() {
    // Calculate score
    currentQuiz.score = 0;
    
    currentQuiz.questions.forEach((question, index) => {
        if (currentQuiz.selectedAnswers[index] === question.correctIndex) {
            currentQuiz.score++;
        }
    });
    
    // Display results
    displayQuizResults();
}

// Display quiz results
function displayQuizResults() {
    // Update UI to show correct/incorrect answers
    currentQuiz.questions.forEach((question, qIndex) => {
        const options = document.querySelectorAll(`.option[data-question="${qIndex}"]`);
        
        options.forEach((option, optIndex) => {
            const isSelected = currentQuiz.selectedAnswers[qIndex] === optIndex;
            const isCorrect = question.correctIndex === optIndex;
            
            option.classList.remove('selected', 'correct', 'incorrect');
            
            if (isCorrect) {
                option.classList.add('correct');
            } else if (isSelected && !isCorrect) {
                option.classList.add('incorrect');
            }
        });
    });
    
    // Show result summary
    quizResults.innerHTML = `
        <div class="quiz-score">You got ${currentQuiz.score} out of ${currentQuiz.questions.length} correct</div>
        <div class="quiz-feedback">
            ${getFeedbackMessage(currentQuiz.score, currentQuiz.questions.length)}
        </div>
        <button id="retry-quiz" class="btn">Try Another Quiz</button>
    `;
    
    // Show results section
    quizResults.classList.remove('hidden');
    
    // Add event listener to retry button
    document.getElementById('retry-quiz').addEventListener('click', closeQuiz);
}

// Get feedback message based on score
function getFeedbackMessage(score, total) {
    const percentage = (score / total) * 100;
    
    if (percentage === 100) {
        return "Excellent! You've mastered this topic. 🏆";
    } else if (percentage >= 70) {
        return "Great job! You have a good understanding of this subject. 👍";
    } else if (percentage >= 50) {
        return "Good effort! With a little more study, you'll master this topic. 📚";
    } else {
        return "Keep learning! This topic might need some more attention. 💪";
    }
}

// Close the quiz
function closeQuiz() {
    quizContainer.classList.add('hidden');
    
    // Reset current quiz
    currentQuiz = {
        videoId: null,
        questions: [],
        selectedAnswers: [],
        score: 0
    };
}

// Show playlist embed modal
function showPlaylistEmbed(embedUrl) {
    // Check if we already have a playlist embed container
    let playlistContainer = document.getElementById('playlist-container');
    
    // If not, create one
    if (!playlistContainer) {
        playlistContainer = document.createElement('div');
        playlistContainer.id = 'playlist-container';
        playlistContainer.className = 'playlist-container';
        document.body.appendChild(playlistContainer);
    }
    
    // Populate the container with the playlist embed and close button
    playlistContainer.innerHTML = `
        <div class="playlist-modal">
            <div class="playlist-header">
                <h3>Course Playlist</h3>
                <button id="close-playlist" class="btn close-btn"><i class="fas fa-times"></i></button>
            </div>
            <div class="playlist-content">
                <iframe src="${embedUrl}" width="100%" height="480" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
    `;
    
    // Show the container
    playlistContainer.classList.add('visible');
    
    // Add close button event listener
    document.getElementById('close-playlist').addEventListener('click', () => {
        playlistContainer.classList.remove('visible');
    });
}
