// YouTube API Service
const YOUTUBE_API_KEY = 'AIzaSyB32O5C4wnn6PgQnyFC60OtcbVXdzK1UZU';

/**
 * Fetch video details from YouTube API
 * @param {string} videoId - YouTube video ID
 * @returns {Promise<Object>} - Promise containing video details
 */
async function getVideoDetails(videoId) {
    try {
        const response = await fetch(
            `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${videoId}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!response.ok) {
            throw new Error('Failed to fetch video details');
        }
        
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
            const videoDetails = data.items[0];
            return {
                title: videoDetails.snippet.title,
                description: videoDetails.snippet.description,
                publishedAt: videoDetails.snippet.publishedAt,
                thumbnail: videoDetails.snippet.thumbnails.high.url,
                viewCount: videoDetails.statistics.viewCount,
                likeCount: videoDetails.statistics.likeCount,
                duration: videoDetails.contentDetails.duration
            };
        } else {
            throw new Error('No video found with the given ID');
        }
    } catch (error) {
        console.error('Error fetching video details:', error);
        return null;
    }
}

/**
 * Fetch playlist details from YouTube API
 * @param {string} playlistId - YouTube playlist ID
 * @returns {Promise<Object>} - Promise containing playlist details and items
 */
async function getPlaylistDetails(playlistId) {
    try {
        // First, get the playlist details
        const playlistResponse = await fetch(
            `https://www.googleapis.com/youtube/v3/playlists?part=snippet,contentDetails&id=${playlistId}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!playlistResponse.ok) {
            throw new Error('Failed to fetch playlist details');
        }
        
        const playlistData = await playlistResponse.json();
        
        if (!playlistData.items || playlistData.items.length === 0) {
            throw new Error('No playlist found with the given ID');
        }
        
        const playlistDetails = playlistData.items[0];
        
        // Then, get the playlist items (videos)
        const itemsResponse = await fetch(
            `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=10&playlistId=${playlistId}&key=${YOUTUBE_API_KEY}`
        );
        
        if (!itemsResponse.ok) {
            throw new Error('Failed to fetch playlist items');
        }
        
        const itemsData = await itemsResponse.json();
        
        // Process video items
        const videos = [];
        
        if (itemsData.items && itemsData.items.length > 0) {
            for (const item of itemsData.items) {
                videos.push({
                    id: item.snippet.resourceId.videoId,
                    title: item.snippet.title,
                    description: item.snippet.description,
                    thumbnail: item.snippet.thumbnails.high ? item.snippet.thumbnails.high.url : 
                               (item.snippet.thumbnails.medium ? item.snippet.thumbnails.medium.url : 
                                item.snippet.thumbnails.default.url),
                    position: item.snippet.position
                });
            }
        }
        
        return {
            id: playlistDetails.id,
            title: playlistDetails.snippet.title,
            description: playlistDetails.snippet.description,
            thumbnail: playlistDetails.snippet.thumbnails.high ? playlistDetails.snippet.thumbnails.high.url : 
                      (playlistDetails.snippet.thumbnails.medium ? playlistDetails.snippet.thumbnails.medium.url : 
                       playlistDetails.snippet.thumbnails.default.url),
            itemCount: playlistDetails.contentDetails.itemCount,
            videos: videos
        };
    } catch (error) {
        console.error('Error fetching playlist details:', error);
        return null;
    }
}

/**
 * Extract playlist ID from a YouTube playlist URL
 * @param {string} url - YouTube playlist URL
 * @returns {string|null} - Playlist ID or null if not found
 */
function extractPlaylistId(url) {
    try {
        const urlObj = new URL(url);
        const params = new URLSearchParams(urlObj.search);
        return params.get('list');
    } catch (error) {
        console.error('Error extracting playlist ID:', error);
        return null;
    }
}