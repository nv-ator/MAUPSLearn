// Function to load course playlists from YouTube
async function loadCoursePlaylists() {
    // Predefined list of FinTech YouTube playlists
    const playlistUrls = [
        'https://www.youtube.com/playlist?list=PLQVvvaa0QuDcOdF96TBtRtuQksErCEBYZ', // Python for Finance
        'https://www.youtube.com/playlist?list=PLUl4u3cNGP61KHzhg3JIJdK08JLSlcLId', // Financial Technology
        'https://www.youtube.com/playlist?list=PLUl4u3cNGP63B2lDhyKOsImI7FjCf6eDW'  // FinTech Investing
    ];

    const coursesData = [];
    
    // Process each playlist
    for (const playlistUrl of playlistUrls) {
        try {
            // Extract the playlist ID
            const playlistId = extractPlaylistId(playlistUrl);
            
            if (!playlistId) {
                console.error('Invalid playlist URL:', playlistUrl);
                continue;
            }
            
            // Fetch playlist details
            const playlistDetails = await getPlaylistDetails(playlistId);
            
            if (!playlistDetails) {
                console.error('Failed to load playlist:', playlistUrl);
                continue;
            }
            
            // Add to courses data
            coursesData.push({
                id: 100 + coursesData.length + 1,
                title: playlistDetails.title,
                description: playlistDetails.description || 'Learn about financial technology concepts and skills.',
                category: 'FinTech',
                level: determineLevel(playlistDetails.title, playlistDetails.description),
                courseLink: playlistUrl,
                playlistEmbedUrl: `https://www.youtube.com/embed/videoseries?list=${playlistId}`,
                thumbnail: playlistDetails.thumbnail,
                videos: processPlaylistVideos(playlistDetails.videos, 100 + coursesData.length + 1)
            });
            
            console.log(`Loaded playlist: ${playlistDetails.title}`);
        } catch (error) {
            console.error('Error loading playlist:', error);
        }
    }
    
    return coursesData;
}

// Process videos from a playlist
function processPlaylistVideos(playlistVideos, courseId) {
    if (!playlistVideos || playlistVideos.length === 0) {
        return [];
    }
    
    return playlistVideos.map((video, index) => {
        return {
            id: courseId * 1000 + index + 1,
            courseId: courseId,
            title: video.title,
            videoUrl: `https://www.youtube.com/embed/${video.id}`,
            category: 'FinTech',
            level: determineLevel(video.title, video.description),
            description: video.description || 'Learn about this financial technology concept.'
        };
    });
}

// Determine content level based on title and description
function determineLevel(title, description) {
    const titleAndDesc = (title + ' ' + (description || '')).toLowerCase();
    
    if (titleAndDesc.includes('beginner') || 
        titleAndDesc.includes('introduction') || 
        titleAndDesc.includes('basics') || 
        titleAndDesc.includes('getting started')) {
        return 'Beginner';
    } else if (titleAndDesc.includes('advanced') || 
               titleAndDesc.includes('expert') || 
               titleAndDesc.includes('in-depth')) {
        return 'Advanced';
    } else {
        return 'Intermediate';
    }
}

// This function will load real YouTube content and update the app
async function loadRealYouTubeContent() {
    const loadingMessage = document.createElement('div');
    loadingMessage.className = 'loading-message';
    loadingMessage.innerHTML = '<p>Loading content from YouTube API...</p>';
    document.querySelector('main').appendChild(loadingMessage);
    
    try {
        // Load real courses data
        const newCourses = await loadCoursePlaylists();
        
        // Compile all videos from courses
        let allVideos = [];
        newCourses.forEach(course => {
            allVideos = [...allVideos, ...course.videos];
        });
        
        // Update global courses and videos arrays
        window.courses = newCourses;
        window.videos = allVideos;
        
        // Display the updated content
        displayCourses();
        populateCourseFilter();
        displayVideos(videos);
        
        console.log('Successfully loaded YouTube content:', {
            courses: newCourses.length,
            videos: allVideos.length
        });
    } catch (error) {
        console.error('Failed to load YouTube content:', error);
        loadingMessage.innerHTML = '<p class="error">Error loading from YouTube API. Using default content.</p>';
    } finally {
        // Remove loading message after a delay
        setTimeout(() => {
            loadingMessage.remove();
        }, 3000);
    }
}

// Initialize with real YouTube content
document.addEventListener('DOMContentLoaded', () => {
    // Wait for existing DOMContentLoaded handlers to complete
    setTimeout(loadRealYouTubeContent, 1000);
});